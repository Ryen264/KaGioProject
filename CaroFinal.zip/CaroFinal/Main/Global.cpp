#include "Global.h"

int currentX;
int currentY;

HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

WORD* pColor = new WORD[nScreenWidth * nScreenHeight];
wchar_t* pBuffer = new wchar_t[nScreenWidth * nScreenHeight];

HANDLE hConsole;
DWORD dwBytesWritten = 0;

bool music = true;
bool sound = true;

int idFile;

Player Player1, Player2;
int CARO_BOARD[BOARD_SIZE][BOARD_SIZE];
_POINT Move;
int Round = 0;


