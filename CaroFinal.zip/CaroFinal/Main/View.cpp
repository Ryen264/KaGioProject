﻿#include "View.h"
using namespace std;

void DisableResizeWindow()
{
	HWND hWnd = GetConsoleWindow();
	SetWindowLong(hWnd, GWL_STYLE, GetWindowLong(hWnd, GWL_STYLE) & ~WS_SIZEBOX);
}
void ShowScrollbar(BOOL Show)
{
	HWND hWnd = GetConsoleWindow();
	ShowScrollBar(hWnd, SB_BOTH, Show);
}
void ShowCur(bool CursorVisibility)
{
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO ConCurInf;

	ConCurInf.dwSize = 10;
	ConCurInf.bVisible = CursorVisibility;

	SetConsoleCursorInfo(handle, &ConCurInf);
}

void Configure()
{
	//Setup colors
	CONSOLE_SCREEN_BUFFER_INFOEX csbiex;
	csbiex.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);
	GetConsoleScreenBufferInfoEx(hStdout, &csbiex);

	csbiex.ColorTable[0] = RGB(0, 0, 0);		//black
	csbiex.ColorTable[1] = RGB(135, 206, 250);	//light sky blue
	csbiex.ColorTable[2] = RGB(255, 255, 255);	//white
	csbiex.ColorTable[3] = RGB(0, 100, 0);		//dark green
	csbiex.ColorTable[4] = RGB(139, 69, 19);	//saddle brown (nau dam)
	csbiex.ColorTable[5] = RGB(205, 133, 63);	//peru (nau nhat)
	csbiex.ColorTable[6] = RGB(139, 0, 0);		//dark red
	csbiex.ColorTable[7] = RGB(255, 165, 0);	//orange
	csbiex.ColorTable[8] = RGB(148, 0, 211);	//dark violet
	csbiex.ColorTable[9] = RGB(255, 99, 71);	//tomato
	csbiex.ColorTable[10] = RGB(255, 128, 0);	//orange (fox)
	csbiex.ColorTable[11] = RGB(60, 179, 113);	//medium sea green
	csbiex.ColorTable[12] = RGB(144, 238, 144);	//light green (xanh la nhat)
	csbiex.ColorTable[13] = RGB(149, 156, 176);	//con chon xanh binh thuong
	csbiex.ColorTable[14] = RGB(105, 115, 143);	//con chon xanh dam nhat
	csbiex.ColorTable[15] = RGB(203, 210, 227);	//con chon xanh nhat nhat

	SetConsoleScreenBufferInfoEx(hStdout, &csbiex);
	//

	//Disable Button
	HWND hWnd = GetConsoleWindow();
	HMENU hMenu = GetSystemMenu(hWnd, false);
	DeleteMenu(hMenu, SC_MAXIMIZE, MF_BYCOMMAND);
	ShowScrollbar(0);
	DisableResizeWindow();
	SetConsoleTitle(L"CARO Project _ Group 7_ 22CLC01 _ HCMUS");
	//

	ShowCur(0);

	//Setup zoom
	CONSOLE_FONT_INFOEX cfiex;
	cfiex.cbSize = sizeof(CONSOLE_FONT_INFOEX);

	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	GetCurrentConsoleFontEx(hConsoleOutput, 0, &cfiex);
	cfiex.dwFontSize.Y = 24;
	SetCurrentConsoleFontEx(hConsoleOutput, 0, &cfiex);
	//

	//Setup WindowSize & ScreenBufferSize
	RECT rectClient, rectWindow;
	GetClientRect(hWnd, &rectClient);
	GetWindowRect(hWnd, &rectWindow);

	MoveWindow(hWnd, 80, 20, nScreenWidth, nScreenHeight, TRUE);

	system("mode 118, 30");
	system("color 10");
	//
	srand(time(0));
}

void Display(int fromX, int fromY, int toX, int toY)
{
	for (int j = fromY; j <= toY; j++)
	{
		for (int i = fromX; i <= toX; i++)
		{
			COORD cPos{};
			cPos.X = i;
			cPos.Y = j;
			WriteConsoleOutputAttribute(hStdout, &pColor[j * nScreenWidth + i], 1, cPos, &dwBytesWritten);

			const wchar_t wchArr[] = { pBuffer[j * nScreenWidth + i] };
			WriteConsoleOutputCharacter(hStdout, wchArr, 1, cPos, &dwBytesWritten);
		}
	}
}
void Display(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int toX, int toY)
{
	for (int j = fromY; j <= toY; j++)
	{
		for (int i = fromX; i <= toX; i++)
		{
			COORD cPos{};
			cPos.X = i;
			cPos.Y = j;
			WriteConsoleOutputAttribute(hStdout, &pColor[j * nScreenWidth + i], 1, cPos, &dwBytesWritten);

			const wchar_t wchArr[] = { pBuffer[j * nScreenWidth + i] };
			WriteConsoleOutputCharacter(hStdout, wchArr, 1, cPos, &dwBytesWritten);
		}
	}
}

void ClearScreen(int background, int text)
{
	for (int i = 0; i < nScreenWidth; i++)
	{
		for (int j = 0; j < nScreenHeight; j++)
		{
			pBuffer[j * nScreenWidth + i] = L' ';
			pColor[j * nScreenWidth + i] = background * 16 + text;
		}
	}
}
void Text(wstring wsContent, WORD wColor, int nPosX, int nPosY)
{
	for (int i = 0; i < wsContent.length(); i++, nPosX++)
	{
		pBuffer[nPosY * nScreenWidth + nPosX] = wsContent.at(i);
		if (pBuffer[nPosY * nScreenWidth + nPosX] != ' ')
		{
			pColor[nPosY * nScreenWidth + nPosX] = wColor;
		}
	}
}
void Text(wchar_t* pBuffer, WORD* pColor, wstring wsContent, WORD wColor, int nPosX, int nPosY)
{
	for (int i = 0; i < wsContent.length(); i++, nPosX++)
	{
		pBuffer[nPosY * nScreenWidth + nPosX] = wsContent.at(i);
		if (pBuffer[nPosY * nScreenWidth + nPosX] != ' ')
		{
			pColor[nPosY * nScreenWidth + nPosX] = wColor;
		}
	}
}

void DrawObject(vector<wstring> wsContent, WORD wColor, int nPosX, int nPosY)
{
	for (int i = 0; i < wsContent.size(); i++)
	{
		Text(wsContent[i], wColor, nPosX, nPosY + i);
	}
}
void DrawObject(wchar_t* pBuffer, WORD* pColor, vector<wstring> wsContent, WORD wColor, int nPosX, int nPosY)
{
	for (int i = 0; i < wsContent.size(); i++)
		Text(pBuffer, pColor, wsContent.at(i), wColor, nPosX, nPosY + i);
}
void Board(int width, int height, int first_x, int first_y)
{
	for (int i = 0; i <= width; i++)
	{
		for (int g = 0; g <= height - 1; g++)
		{
			int X = i * 4 + first_x, Y = 2 * g + 1 + first_y;
			pBuffer[Y * nScreenWidth + X] = L'│';
		}

		for (int j = 0; j <= height; j++)
		{
			int X = i * 4 + first_x, Y = j * 2 + first_y;
			pBuffer[Y * nScreenWidth + X] = L'┼';
			if (i != width)
			{
				for (int g = (i * 4 + 1); g <= 4 * i + 3; g++)
				{
					int X = g + first_x, Y = j * 2 + first_y;
					pBuffer[Y * nScreenWidth + X] = L'─';
				}
			}
		}
	}
	Frame(width, height, first_x, first_y, L"");
}
void Frame(int width, int height, int first_x, int first_y, wstring wsCaption) {
	int X = width * 4 + first_x;
	int Y = height * 2 + first_y;
	for (int i = first_x; i <= X; i++)		//Top bar
		pBuffer[first_y * nScreenWidth + i] = L'═';
	pBuffer[first_y * nScreenWidth + X] = L'╗';

	for (int i = first_y + 1; i <= Y; i++)	//Right bar
		pBuffer[i * nScreenWidth + X] = L'║';
	pBuffer[Y * nScreenWidth + X] = L'╝';

	for (int i = X - 1; i >= first_x; i--)	//Bottom bar
		pBuffer[Y * nScreenWidth + i] = L'═';
	pBuffer[Y * nScreenWidth + first_x] = L'╚';

	for (int i = Y - 1; i >= first_y; i--)	//Left bar
		pBuffer[i * nScreenWidth + first_x] = L'║';
	pBuffer[first_y * nScreenWidth + first_x] = L'╔';

	int CapIndex = first_y * nScreenWidth + first_x + width / 3;
	for (int i = 0; i < wsCaption.length(); i++, CapIndex++)
		pBuffer[CapIndex] = wsCaption.at(i);
}

void drawGrass(int fromX, int fromY)
{
	for (int i = fromX; i < nScreenWidth - 1; i = i + 9)
	{
		//col 1
		pBuffer[(fromY)*nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY)*nScreenWidth + (fromX + i)] = 12 * 16 + 12;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i)] = 12 * 16 + 11;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i)] = 3 * 16 + 4;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i)] = 4 * 16 + 4;

		//col 2
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 1)] = L'█';
		pColor[(fromY)*nScreenWidth + (fromX + i + 1)] = 12 * 16 + 12;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 1)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 1)] = 11 * 16 + 3;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 1)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 1)] = 3 * 16 + 3;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 1)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 1)] = 4 * 16 + 4;

		//col 3
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 2)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX + i + 2)] = 12 * 16 + 11;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 2)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 2)] = 11 * 16 + 3;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 2)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 2)] = 3 * 16 + 4;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 2)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 2)] = 5 * 16 + 4;

		//col 4
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 3)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX + i + 3)] = 12 * 16 + 11;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 3)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 3)] = 11 * 16 + 3;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 3)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 3)] = 4 * 16 + 5;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 3)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 3)] = 5 * 16 + 4;

		//col 5
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 4)] = L'█';
		pColor[(fromY)*nScreenWidth + (fromX + i + 4)] = 12 * 16 + 12;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 4)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 4)] = 12 * 16 + 11;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 4)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 4)] = 3 * 16 + 4;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 4)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 4)] = 5 * 16 + 4;

		//col 6
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 5)] = L'█';
		pColor[(fromY)*nScreenWidth + (fromX + i + 5)] = 12 * 16 + 12;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 5)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 5)] = 11 * 16 + 3;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 5)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 5)] = 3 * 16 + 3;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 5)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 5)] = 4 * 16 + 4;

		//col 7
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 6)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX + i + 6)] = 12 * 16 + 11;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 6)] = L'█';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 6)] = 3 * 16 + 3;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 6)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 6)] = 3 * 16 + 4;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 6)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 6)] = 4 * 16 + 5;

		//col 8
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 7)] = L'▄';
		pColor[(fromY)*nScreenWidth + (fromX + i + 7)] = 12 * 16 + 11;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 7)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 7)] = 11 * 16 + 3;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 7)] = L'█';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 7)] = 4 * 16 + 4;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 7)] = L'█';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 7)] = 5 * 16 + 5;

		//col 9
		pBuffer[(fromY)*nScreenWidth + (fromX + i + 8)] = L'█';
		pColor[(fromY)*nScreenWidth + (fromX + i + 8)] = 12 * 16 + 12;
		pBuffer[(fromY + 1) * nScreenWidth + (fromX + i + 8)] = L'▄';
		pColor[(fromY + 1) * nScreenWidth + (fromX + i + 8)] = 11 * 16 + 3;
		pBuffer[(fromY + 2) * nScreenWidth + (fromX + i + 8)] = L'▄';
		pColor[(fromY + 2) * nScreenWidth + (fromX + i + 8)] = 3 * 16 + 4;
		pBuffer[(fromY + 3) * nScreenWidth + (fromX + i + 8)] = L'▄';
		pColor[(fromY + 3) * nScreenWidth + (fromX + i + 8)] = 4 * 16 + 5;
	}
	pBuffer[(fromY)*nScreenWidth + (fromX + 117)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 117)] = 12 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 117)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 117)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 117)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 117)] = 3 * 16 + 4;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 117)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 117)] = 4 * 16 + 4;
}
void drawCloud(int fromX, int fromY)
{
	//col 1
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 1)] = 1 * 16 + 15;

	//col 2
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = 1 * 16 + 15;

	//col 3
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 1 * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 1 * 16 + 15;

	//col 4
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 1 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 1 * 16 + 15;

	//col 5
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 1 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = 2 * 16 + 15;

	//col 6
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 2 * 16 + 15;

	//col 7
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 1 * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = 2 * 16 + 15;

	//col 8
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = 15 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = 2 * 16 + 15;

	//col 9
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = 15 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = 1 * 16 + 15;

	//col 10
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = 1 * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = 15 * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = 15 * 16 + 15;

	//col 11
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = 15 * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = 15 * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = 2 * 16 + 15;

	//col 12
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 1 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = 15 * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = 15 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = 2 * 16 + 15;

	//col 13
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 15 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = 15 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = 2 * 16 + 15;

	//col 14
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 2 * 16 + 2;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = 2 * 16 + 15;

	//col 15
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 2 * 16 + 2;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 2 * 16 + 15;

	//col 16
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 2 * 16 + 2;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 2 * 16 + 15;

	//col 17
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = 1 * 16 + 2;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = 2 * 16 + 15;

	//col 18
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = 1 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = 2 * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = 15 * 16 + 15;

	//col 19
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 15 * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = 15 * 16 + 15;

	//col 20
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 20)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 20)] = 15 * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 20)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 20)] = 2 * 16 + 15;

	//col 21
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 21)] = 2 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 21)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 21)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 21)] = 2 * 16 + 15;

	//col 22
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 22)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 22)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 22)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 22)] = 2 * 16 + 15;

	//col 23
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 23)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 23)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 23)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 23)] = 2 * 16 + 15;

	//col 24
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 24)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 24)] = 2 * 16 + 15;
}
void drawTree(int fromX, int fromY)
{
	//col 1
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 1)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 1)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 1)] = 11 * 16 + 11;

	//col 2
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = 12 * 16 + 12;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 2)] = 11 * 16 + 12;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 2)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 2)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 2)] = 3 * 16 + 3;

	//col 3
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 12 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 11 * 16 + 12;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 3)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 3)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 3)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 3)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 3)] = 1 * 16 + 3;

	//col 4
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 1 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 11 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 4)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 4)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 4)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 4)] = 1 * 16 + 3;

	//col 5
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 1 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 11 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 5)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 5)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 5)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 5)] = 3 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 5)] = 1 * 16 + 3;

	//col 6
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 1 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 11 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 6)] = 11 * 16 + 3;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 6)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 6)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 6)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 6)] = 3 * 16 + 3;

	//col 7
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = 12 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 12 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = 12 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 7)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 7)] = 11 * 16 + 3;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 7)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 7)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 7)] = 3 * 16 + 3;

	//col 8
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = 1 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = 12 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = 12 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = 11 * 16 + 12;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] = 11 * 16 + 12;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 8)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 8)] = 3 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 8)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 8)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 8)] = 1 * 16 + 3;

	//col 9
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 1 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = 12 * 16 + 11;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = 11 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] = 11 * 16 + 12;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 9)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 9)] = 3 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 9)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 9)] = 3 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 9)] = 3 * 16 + 3;

	//col 10
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 1 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = 12 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = 11 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 10)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = 11 * 16 + 12;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 10)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 10)] = 3 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 10)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 10)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 10)] = 3 * 16 + 11;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 10)] = 4 * 16 + 3;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 10)] = 5 * 16 + 5;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 10)] = 5 * 16 + 5;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 10)] = 5 * 16 + 5;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 10)] = 4 * 16 + 5;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 10)] = 4 * 16 + 4;
	pBuffer[(fromY + 17) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 17) * nScreenWidth + (fromX + 10)] = 4 * 16 + 4;
	pBuffer[(fromY + 18) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 18) * nScreenWidth + (fromX + 10)] = 4 * 16 + 4;
	pBuffer[(fromY + 19) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 19) * nScreenWidth + (fromX + 10)] = 4 * 16 + 4;

	//col 11
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = 12 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 11)] = 11 * 16 + 12;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 11)] = 11 * 16 + 3;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 11)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 11)] = 3 * 16 + 11;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 11)] = 4 * 16 + 3;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 11)] = 5 * 16 + 5;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 11)] = 5 * 16 + 5;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 11)] = 5 * 16 + 5;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 11)] = 5 * 16 + 5;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 11)] = 4 * 16 + 4;
	pBuffer[(fromY + 17) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 17) * nScreenWidth + (fromX + 11)] = 4 * 16 + 4;
	pBuffer[(fromY + 18) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 18) * nScreenWidth + (fromX + 11)] = 4 * 16 + 4;
	pBuffer[(fromY + 19) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 19) * nScreenWidth + (fromX + 11)] = 4 * 16 + 4;

	//col 12
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 12 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 12)] = 12 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 12)] = 11 * 16 + 3;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 12)] = 3 * 16 + 11;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 12)] = 4 * 16 + 3;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 12)] = 5 * 16 + 5;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 12)] = 5 * 16 + 5;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 12)] = 5 * 16 + 5;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 12)] = 4 * 16 + 5;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 12)] = 4 * 16 + 4;
	pBuffer[(fromY + 17) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 17) * nScreenWidth + (fromX + 12)] = 4 * 16 + 4;
	pBuffer[(fromY + 18) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 18) * nScreenWidth + (fromX + 12)] = 4 * 16 + 4;
	pBuffer[(fromY + 19) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 19) * nScreenWidth + (fromX + 12)] = 4 * 16 + 4;

	//col 13
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 12 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = 12 * 16 + 11;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 13)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 13)] = 11 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 13)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 13)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 13)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 13)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 13)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 13)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 13)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 13)] = 3 * 16 + 11;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 13)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 13)] = 4 * 16 + 3;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 13)] = 5 * 16 + 5;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 13)] = 5 * 16 + 5;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 13)] = 5 * 16 + 5;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 13)] = 4 * 16 + 4;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 13)] = 4 * 16 + 4;
	pBuffer[(fromY + 17) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 17) * nScreenWidth + (fromX + 13)] = 4 * 16 + 4;
	pBuffer[(fromY + 18) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 18) * nScreenWidth + (fromX + 13)] = 4 * 16 + 4;
	pBuffer[(fromY + 19) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 19) * nScreenWidth + (fromX + 13)] = 4 * 16 + 4;

	//col 14
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 12 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = 12 * 16 + 11;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 14)] = 11 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 14)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 14)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 14)] = 3 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 14)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 14)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 14)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 14)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 14)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 14)] = 3 * 16 + 11;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 14)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 14)] = 5 * 16 + 4;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 14)] = 5 * 16 + 5;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 14)] = 4 * 16 + 4;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 14)] = 4 * 16 + 4;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 14)] = 4 * 16 + 4;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 14)] = 4 * 16 + 4;
	pBuffer[(fromY + 17) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 17) * nScreenWidth + (fromX + 14)] = 4 * 16 + 4;
	pBuffer[(fromY + 18) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 18) * nScreenWidth + (fromX + 14)] = 4 * 16 + 4;
	pBuffer[(fromY + 19) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 19) * nScreenWidth + (fromX + 14)] = 4 * 16 + 4;

	//col 15
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 12 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = 12 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 15)] = 11 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 15)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 15)] = 11 * 16 + 12;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 15)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 15)] = L'▀';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 15)] = 11 * 16 + 3;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 15)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 15)] = L'▀';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 15)] = 11 * 16 + 12;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 15)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 15)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 15)] = 1 * 16 + 3;

	//col 16
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 1 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = 12 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 16)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 16)] = 11 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 16)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 16)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 16)] = L'▀';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 16)] = 11 * 16 + 3;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 16)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 16)] = 12 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 16)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 16)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 16)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 16)] = 3 * 16 + 11;

	//col 17
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = 11 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 17)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 17)] = 12 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 17)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 17)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 17)] = L'▀';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 17)] = 11 * 16 + 3;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 17)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 17)] = 12 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 17)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 17)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 17)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 17)] = 3 * 16 + 11;

	//col 18
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = 11 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 18)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 18)] = 12 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 18)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 18)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 18)] = L'▀';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 18)] = 11 * 16 + 3;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 18)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 18)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 18)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 18)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 18)] = 3 * 16 + 11;

	//col 19
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = 11 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 19)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 19)] = 12 * 16 + 11;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 19)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 19)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 19)] = 3 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 19)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 19)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 19)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 19)] = 11 * 16 + 11;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 19)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 19)] = 1 * 16 + 3;

	//col 20
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 20)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 20)] = 1 * 16 + 12;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 20)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 20)] = 11 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 20)] = 11 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 20)] = L'▄';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 20)] = 11 * 16 + 3;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 20)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 20)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 20)] = 11 * 16 + 11;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 20)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 20)] = 3 * 16 + 11;

	//col 21
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 21)] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 21)] = 1 * 16 + 12;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 21)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 21)] = 12 * 16 + 11;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 21)] = 11 * 16 + 11;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 21)] = 11 * 16 + 11;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 21)] = 11 * 16 + 11;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 21)] = 3 * 16 + 3;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 21)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 21)] = 1 * 16 + 3;

	//col 22
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 22)] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 22)] = 1 * 16 + 12;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 22)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 22)] = 12 * 16 + 12;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 22)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 22)] = 12 * 16 + 12;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 22)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 22)] = 1 * 16 + 12;
}
void drawBushes(int fromX, int fromY)
{
	//col 1
	pBuffer[(fromY + 2) * nScreenWidth + (fromX)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX)] = 1 * 16 + 12;

	//col 2
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = 12 * 16 + 11;

	//col 3
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 1 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 11 * 16 + 3;

	//col 4
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 3 * 16 + 3;

	//col 5
	pBuffer[(fromY)*nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 4)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 4)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 11 * 16 + 3;

	//col 6
	pBuffer[(fromY)*nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 5)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 5)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 5)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 3 * 16 + 3;

	//col 7
	pBuffer[(fromY)*nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 6)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 6)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 11 * 16 + 3;

	//col 8
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 7)] = 12 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = 11 * 16 + 3;

	//col 9
	pBuffer[(fromY)*nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 8)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = 11 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = 3 * 16 + 3;

	//col 10
	pBuffer[(fromY)*nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 9)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = 3 * 16 + 3;

	//col 11
	pBuffer[(fromY)*nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 10)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 10)] = 11 * 16 + 3;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = 11 * 16 + 3;

	//col 12
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 11)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 11)] = 3 * 16 + 3;

	//col 13
	pBuffer[(fromY)*nScreenWidth + (fromX + 12)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 12)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 12)] = 11 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 12)] = 3 * 16 + 3;

	//col 14
	pBuffer[(fromY)*nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY)*nScreenWidth + (fromX + 13)] = 12 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 13)] = 11 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 13)] = 3 * 16 + 3;

	//col 15
	pBuffer[(fromY)*nScreenWidth + (fromX + 14)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 14)] = 12 * 16 + 11;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 14)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 14)] = 11 * 16 + 3;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 14)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 14)] = 11 * 16 + 3;

	//col 16
	pBuffer[(fromY)*nScreenWidth + (fromX + 15)] = L'▄';
	pColor[(fromY)*nScreenWidth + (fromX + 15)] = 1 * 16 + 12;
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 15)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 15)] = 11 * 16 + 3;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 15)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 15)] = 11 * 16 + 3;

	//col 17
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 16)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 16)] = 12 * 16 + 11;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 16)] = 3 * 16 + 3;

	//col 18
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 17)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 17)] = 1 * 16 + 12;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 17)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 17)] = 11 * 16 + 3;

	//col 19
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 18)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 18)] = 12 * 16 + 11;

	//col 20
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 19)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 19)] = 1 * 16 + 12;
}
void drawWease(int fromX, int fromY)
{
	pBuffer[fromY * nScreenWidth + fromX] = L'█';
	pColor[fromY * nScreenWidth + fromX] = (pColor[fromY * nScreenWidth + fromX] / 16) * 16 + 15;
	pBuffer[(fromY + 1) * nScreenWidth + fromX] = L'█';
	pColor[(fromY + 1) * nScreenWidth + fromX] = (pColor[(fromY + 1) * nScreenWidth + fromX] / 16) * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX] = (pColor[(fromY + 2) * nScreenWidth + fromX] / 16) * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + fromX] = (pColor[(fromY + 3) * nScreenWidth + fromX] / 16) * 16 + 13;

	pBuffer[fromY * nScreenWidth + fromX + 1] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 1] = (pColor[fromY * nScreenWidth + fromX + 1] / 16) * 16 + 15;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 1] = L'█';
	pColor[(fromY + 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + 1) * nScreenWidth + fromX + 1] / 16) * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 1] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 1] = (pColor[(fromY + 2) * nScreenWidth + fromX + 1] / 16) * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 1] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 1] = (pColor[(fromY + 3) * nScreenWidth + fromX + 1] / 16) * 16 + 13;

	pBuffer[fromY * nScreenWidth + fromX + 2] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 2] = (pColor[fromY * nScreenWidth + fromX + 2] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 2] = L'█';
	pColor[(fromY + 1) * nScreenWidth + fromX + 2] = (pColor[(fromY + 1) * nScreenWidth + fromX + 2] / 16) * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 2] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 2] = (pColor[(fromY + 2) * nScreenWidth + fromX + 2] / 16) * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 2] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 2] = (pColor[(fromY + 3) * nScreenWidth + fromX + 2] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 2] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + fromX + 2] = (pColor[(fromY + 4) * nScreenWidth + fromX + 2] / 16) * 16 + 13;

	pBuffer[fromY * nScreenWidth + fromX + 3] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 3] = (pColor[fromY * nScreenWidth + fromX] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 3] = L'█';
	pColor[(fromY + 1) * nScreenWidth + fromX + 3] = (pColor[(fromY + 1) * nScreenWidth + fromX + 3] / 16) * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 3] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 3] = (pColor[(fromY + 2) * nScreenWidth + fromX + 3] / 16) * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 3] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 3] = (pColor[(fromY + 3) * nScreenWidth + fromX + 3] / 16) * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 3] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + fromX + 3] = 2 * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 3] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 3] = (pColor[(fromY + 5) * nScreenWidth + fromX + 3] / 16) * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 3] = L'▀';
	pColor[(fromY + 6) * nScreenWidth + fromX + 3] = (pColor[(fromY + 6) * nScreenWidth + fromX + 3] / 16) * 16 + 2;

	pBuffer[fromY * nScreenWidth + fromX + 4] = L'█';
	pColor[fromY * nScreenWidth + fromX + 4] = (pColor[fromY * nScreenWidth + fromX + 4] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 4] = L'█';
	pColor[(fromY + 1) * nScreenWidth + fromX + 4] = (pColor[(fromY + 1) * nScreenWidth + fromX + 4] / 16) * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 4] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 4] = (pColor[(fromY + 2) * nScreenWidth + fromX + 4] / 16) * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 4] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 4] = (pColor[(fromY + 3) * nScreenWidth + fromX + 4] / 16) * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 4] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 4] = (pColor[(fromY + 4) * nScreenWidth + fromX + 4] / 16) * 16 + 2;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 4] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 4] = (pColor[(fromY + 5) * nScreenWidth + fromX + 4] / 16) * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 4] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 4] = (pColor[(fromY + 6) * nScreenWidth + fromX + 4] / 16) * 16 + 2;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 4] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + fromX + 4] = (pColor[(fromY + 7) * nScreenWidth + fromX + 4] / 16) * 16 + 0;

	pBuffer[(fromY - 1) * nScreenWidth + fromX + 5] = L'▄';
	pColor[(fromY - 1) * nScreenWidth + fromX + 5] = (pColor[(fromY - 1) * nScreenWidth + fromX + 5] / 16) * 16 + 15;
	pBuffer[fromY * nScreenWidth + fromX + 5] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 5] = 15 * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 5] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 5] = 13 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 5] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 5] = (pColor[(fromY + 2) * nScreenWidth + fromX + 5] / 16) * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 5] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 5] = (pColor[(fromY + 3) * nScreenWidth + fromX + 5] / 16) * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 5] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 5] = (pColor[(fromY + 4) * nScreenWidth + fromX + 5] / 16) * 16 + 2;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 5] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 5] = (pColor[(fromY + 5) * nScreenWidth + fromX + 5] / 16) * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 5] = L'▄';
	pColor[(fromY + 6) * nScreenWidth + fromX + 5] = 2 * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 5] = L'▄';
	pColor[(fromY + 7) * nScreenWidth + fromX + 5] = 13 * 16 + 0;

	pBuffer[(fromY - 1) * nScreenWidth + fromX + 6] = L'█';
	pColor[(fromY - 1) * nScreenWidth + fromX + 6] = (pColor[(fromY - 1) * nScreenWidth + fromX + 6] / 16) * 16 + 13;
	pBuffer[fromY * nScreenWidth + fromX + 6] = L'█';
	pColor[fromY * nScreenWidth + fromX + 6] = (pColor[fromY * nScreenWidth + fromX + 6] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 6] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 6] = 13 * 16 + 0;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 6] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 6] = 13 * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 6] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 6] = 15 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 6] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 6] = (pColor[(fromY + 4) * nScreenWidth + fromX + 6] / 16) * 16 + 2;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 6] = L'▄';
	pColor[(fromY + 5) * nScreenWidth + fromX + 6] = 2 * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 6] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 6] = (pColor[(fromY + 6) * nScreenWidth + fromX + 6] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 6] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 6] = (pColor[(fromY + 7) * nScreenWidth + fromX + 6] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 6] = L'█';
	pColor[(fromY + 8) * nScreenWidth + fromX + 6] = (pColor[(fromY + 8) * nScreenWidth + fromX + 6] / 16) * 16 + 0;
	pBuffer[(fromY + 9) * nScreenWidth + fromX + 6] = L'█';
	pColor[(fromY + 9) * nScreenWidth + fromX + 6] = (pColor[(fromY + 9) * nScreenWidth + fromX + 6] / 16) * 16 + 0;

	pBuffer[fromY * nScreenWidth + fromX + 7] = L'█';
	pColor[fromY * nScreenWidth + fromX + 7] = (pColor[fromY * nScreenWidth + fromX + 7] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 7] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 7] = 13 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 7] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 7] = (pColor[(fromY + 2) * nScreenWidth + fromX + 7] / 16) * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 7] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 7] = 15 * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 7] = L'▄';
	pColor[(fromY + 4) * nScreenWidth + fromX + 7] = 2 * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 7] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 7] = (pColor[(fromY + 5) * nScreenWidth + fromX + 7] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 7] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 7] = (pColor[(fromY + 6) * nScreenWidth + fromX + 7] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 7] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 7] = (pColor[(fromY + 7) * nScreenWidth + fromX + 7] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 7] = L'▀';
	pColor[(fromY + 8) * nScreenWidth + fromX + 7] = (pColor[(fromY + 8) * nScreenWidth + fromX + 7] / 16) * 16 + 13;

	pBuffer[fromY * nScreenWidth + fromX + 8] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 8] = (pColor[fromY * nScreenWidth + fromX + 8] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 8] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 8] = 13 * 16 + 15;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 8] = (pColor[(fromY + 2) * nScreenWidth + fromX + 8] / 16) * 16 + 15;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 8] = (pColor[(fromY + 3) * nScreenWidth + fromX + 8] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 8] = (pColor[(fromY + 4) * nScreenWidth + fromX + 8] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 8] = (pColor[(fromY + 5) * nScreenWidth + fromX + 8] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 8] = (pColor[(fromY + 6) * nScreenWidth + fromX + 8] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 8] = (pColor[(fromY + 7) * nScreenWidth + fromX + 8] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 8) * nScreenWidth + fromX + 8] = (pColor[(fromY + 8) * nScreenWidth + fromX + 8] / 16) * 16 + 13;
	pBuffer[(fromY + 9) * nScreenWidth + fromX + 8] = L'█';
	pColor[(fromY + 9) * nScreenWidth + fromX + 8] = (pColor[(fromY + 9) * nScreenWidth + fromX + 8] / 16) * 16 + 13;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + 9] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 9] = 13 * 16 + 0;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 9] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 9] = 15 * 16 + 0;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 9] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + fromX + 9] = (pColor[(fromY + 3) * nScreenWidth + fromX + 9] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 9] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 9] = (pColor[(fromY + 4) * nScreenWidth + fromX + 9] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 9] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 9] = (pColor[(fromY + 5) * nScreenWidth + fromX + 9] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 9] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 9] = (pColor[(fromY + 6) * nScreenWidth + fromX + 9] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 9] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 9] = (pColor[(fromY + 7) * nScreenWidth + fromX + 9] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 9] = L'▀';
	pColor[(fromY + 8) * nScreenWidth + fromX + 9] = (pColor[(fromY + 8) * nScreenWidth + fromX + 9] / 16) * 16 + 13;

	pBuffer[(fromY + 2) * nScreenWidth + fromX + 10] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 10] = 15 * 16;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 10] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + fromX + 10] = (pColor[(fromY + 3) * nScreenWidth + fromX + 10] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 10] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 10] = (pColor[(fromY + 4) * nScreenWidth + fromX + 10] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 10] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 10] = (pColor[(fromY + 5) * nScreenWidth + fromX + 10] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 10] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 10] = (pColor[(fromY + 6) * nScreenWidth + fromX + 10] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 10] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 10] = (pColor[(fromY + 7) * nScreenWidth + fromX + 10] / 16) * 16 + 13;

	pBuffer[(fromY + 4) * nScreenWidth + fromX + 11] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 11] = (pColor[(fromY + 4) * nScreenWidth + fromX + 11] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 11] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 11] = (pColor[(fromY + 5) * nScreenWidth + fromX + 11] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 11] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 11] = (pColor[(fromY + 6) * nScreenWidth + fromX + 11] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 11] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + fromX + 11] = (pColor[(fromY + 7) * nScreenWidth + fromX + 11] / 16) * 16 + 13;

	pBuffer[(fromY + 3) * nScreenWidth + fromX + 12] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 12] = (pColor[(fromY + 3) * nScreenWidth + fromX + 12] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 12] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 12] = (pColor[(fromY + 4) * nScreenWidth + fromX + 12] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 12] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 12] = (pColor[(fromY + 5) * nScreenWidth + fromX + 12] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 12] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 12] = 13 * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 12] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + fromX + 12] = (pColor[(fromY + 7) * nScreenWidth + fromX + 12] / 16) * 16 + 14;

	pBuffer[(fromY + 3) * nScreenWidth + fromX + 13] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 13] = (pColor[(fromY + 3) * nScreenWidth + fromX + 13] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 13] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 13] = (pColor[(fromY + 4) * nScreenWidth + fromX + 13] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 13] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 13] = (pColor[(fromY + 5) * nScreenWidth + fromX + 13] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 13] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 13] = (pColor[(fromY + 6) * nScreenWidth + fromX + 13] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 13] = L'▄';
	pColor[(fromY + 7) * nScreenWidth + fromX + 13] = 14 * 16 + 0;

	pBuffer[(fromY + 3) * nScreenWidth + fromX + 14] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 14] = (pColor[(fromY + 3) * nScreenWidth + fromX + 14] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 14] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 14] = (pColor[(fromY + 4) * nScreenWidth + fromX + 14] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 14] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 14] = (pColor[(fromY + 5) * nScreenWidth + fromX + 14] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 14] = L'▄';
	pColor[(fromY + 6) * nScreenWidth + fromX + 14] = 13 * 16 + 14;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 14] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 14] = (pColor[(fromY + 7) * nScreenWidth + fromX + 14] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 14] = L'▀';
	pColor[(fromY + 8) * nScreenWidth + fromX + 14] = (pColor[(fromY + 8) * nScreenWidth + fromX + 14] / 16) * 16 + 0;

	pBuffer[(fromY + 3) * nScreenWidth + fromX + 15] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 15] = (pColor[(fromY + 3) * nScreenWidth + fromX + 15] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 15] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 15] = (pColor[(fromY + 4) * nScreenWidth + fromX + 15] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 15] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 15] = (pColor[(fromY + 5) * nScreenWidth + fromX + 15] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 15] = L'▄';
	pColor[(fromY + 6) * nScreenWidth + fromX + 15] = 13 * 16 + 14;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 15] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 15] = (pColor[(fromY + 7) * nScreenWidth + fromX + 15] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 15] = L'▄';
	pColor[(fromY + 8) * nScreenWidth + fromX + 15] = 13 * 16 + 0;
	pBuffer[(fromY + 9) * nScreenWidth + fromX + 15] = L'█';
	pColor[(fromY + 9) * nScreenWidth + fromX + 15] = (pColor[(fromY + 9) * nScreenWidth + fromX + 15] / 16) * 16 + 0;

	pBuffer[(fromY + 3) * nScreenWidth + fromX + 16] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 16] = 15 * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 16] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 16] = (pColor[(fromY + 4) * nScreenWidth + fromX + 16] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 16] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 16] = (pColor[(fromY + 5) * nScreenWidth + fromX + 16] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 16] = L'▄';
	pColor[(fromY + 6) * nScreenWidth + fromX + 16] = 13 * 16 + 14;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 16] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 16] = (pColor[(fromY + 7) * nScreenWidth + fromX + 16] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 16] = L'█';
	pColor[(fromY + 8) * nScreenWidth + fromX + 16] = (pColor[(fromY + 8) * nScreenWidth + fromX + 16] / 16) * 16 + 13;
	pBuffer[(fromY + 9) * nScreenWidth + fromX + 16] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + fromX + 16] = (pColor[(fromY + 9) * nScreenWidth + fromX + 16] / 16) * 16 + 13;

	pBuffer[(fromY + 3) * nScreenWidth + fromX + 17] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 17] = 15 * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 17] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 17] = (pColor[(fromY + 4) * nScreenWidth + fromX + 17] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 17] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 17] = (pColor[(fromY + 5) * nScreenWidth + fromX + 17] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 17] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 17] = (pColor[(fromY + 6) * nScreenWidth + fromX + 17] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 17] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 17] = (pColor[(fromY + 7) * nScreenWidth + fromX + 17] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 17] = L'█';
	pColor[(fromY + 8) * nScreenWidth + fromX + 17] = (pColor[(fromY + 8) * nScreenWidth + fromX + 17] / 16) * 16 + 13;
	pBuffer[(fromY + 9) * nScreenWidth + fromX + 17] = L'█';
	pColor[(fromY + 9) * nScreenWidth + fromX + 17] = (pColor[(fromY + 9) * nScreenWidth + fromX + 17] / 16) * 16 + 13;


	pBuffer[(fromY + 3) * nScreenWidth + fromX + 18] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 18] = 15 * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 18] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 18] = (pColor[(fromY + 4) * nScreenWidth + fromX + 18] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 18] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 18] = (pColor[(fromY + 5) * nScreenWidth + fromX + 18] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 18] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 18] = (pColor[(fromY + 6) * nScreenWidth + fromX + 18] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 18] = L'█';
	pColor[(fromY + 7) * nScreenWidth + fromX + 18] = (pColor[(fromY + 7) * nScreenWidth + fromX + 18] / 16) * 16 + 13;
	pBuffer[(fromY + 8) * nScreenWidth + fromX + 18] = L'▀';
	pColor[(fromY + 8) * nScreenWidth + fromX + 18] = (pColor[(fromY + 8) * nScreenWidth + fromX + 18] / 16) * 16 + 15;

	pBuffer[(fromY + 3) * nScreenWidth + fromX + 19] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 19] = (pColor[(fromY + 3) * nScreenWidth + fromX + 19] / 16) * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 19] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 19] = (pColor[(fromY + 4) * nScreenWidth + fromX + 19] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 19] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 19] = (pColor[(fromY + 5) * nScreenWidth + fromX + 19] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 19] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 19] = (pColor[(fromY + 6) * nScreenWidth + fromX + 19] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 19] = L'▄';
	pColor[(fromY + 7) * nScreenWidth + fromX + 19] = 13 * 16 + 15;

	pBuffer[(fromY - 1) * nScreenWidth + fromX + 20] = L'▄';
	pColor[(fromY - 1) * nScreenWidth + fromX + 20] = (pColor[(fromY - 1) * nScreenWidth + fromX + 20] / 16) * 16 + 14;
	pBuffer[fromY * nScreenWidth + fromX + 20] = L'█';
	pColor[fromY * nScreenWidth + fromX + 20] = (pColor[fromY * nScreenWidth + fromX + 20] / 16) * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 20] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 20] = (pColor[(fromY + 3) * nScreenWidth + fromX + 20] / 16) * 16 + 15;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 20] = L'█';
	pColor[(fromY + 4) * nScreenWidth + fromX + 20] = (pColor[(fromY + 4) * nScreenWidth + fromX + 20] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 20] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 20] = (pColor[(fromY + 5) * nScreenWidth + fromX + 20] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 20] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 20] = (pColor[(fromY + 6) * nScreenWidth + fromX + 20] / 16) * 16 + 13;
	pBuffer[(fromY + 7) * nScreenWidth + fromX + 20] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + fromX + 20] = (pColor[(fromY + 7) * nScreenWidth + fromX + 20] / 16) * 16 + 15;

	pBuffer[(fromY - 1) * nScreenWidth + fromX + 21] = L'▄';
	pColor[(fromY - 1) * nScreenWidth + fromX + 21] = 13 * 16 + 14;
	pBuffer[fromY * nScreenWidth + fromX + 21] = L'█';
	pColor[fromY * nScreenWidth + fromX + 21] = (pColor[fromY * nScreenWidth + fromX + 21] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 21] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 21] = 14 * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 21] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + fromX + 21] = (pColor[(fromY + 4) * nScreenWidth + fromX + 21] / 16) * 16 + 13;
	pBuffer[(fromY + 5) * nScreenWidth + fromX + 21] = L'█';
	pColor[(fromY + 5) * nScreenWidth + fromX + 21] = (pColor[(fromY + 5) * nScreenWidth + fromX + 21] / 16) * 16 + 13;
	pBuffer[(fromY + 6) * nScreenWidth + fromX + 21] = L'█';
	pColor[(fromY + 6) * nScreenWidth + fromX + 21] = (pColor[(fromY + 6) * nScreenWidth + fromX + 21] / 16) * 16 + 15;

	pBuffer[(fromY - 2) * nScreenWidth + fromX + 22] = L'▄';
	pColor[(fromY - 2) * nScreenWidth + fromX + 22] = 14 * 16 + 13;
	pBuffer[(fromY - 1) * nScreenWidth + fromX + 22] = L'▄';
	pColor[(fromY - 1) * nScreenWidth + fromX + 22] = 13 * 16 + 14;
	pBuffer[fromY * nScreenWidth + fromX + 22] = L'█';
	pColor[fromY * nScreenWidth + fromX + 22] = (pColor[fromY * nScreenWidth + fromX + 22] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 22] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 22] = 14 * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 22] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 22] = 13 * 16 + 14;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 22] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 22] = (pColor[(fromY + 3) * nScreenWidth + fromX + 22] / 16) * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 22] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + fromX + 22] = (pColor[(fromY + 4) * nScreenWidth + fromX + 22] / 16) * 16 + 13;

	pBuffer[(fromY - 3) * nScreenWidth + fromX + 23] = L'▄';
	pColor[(fromY - 3) * nScreenWidth + fromX + 23] = (pColor[(fromY - 3) * nScreenWidth + fromX + 23] / 16) * 16 + 13;
	pBuffer[(fromY - 2) * nScreenWidth + fromX + 23] = L'▄';
	pColor[(fromY - 2) * nScreenWidth + fromX + 23] = 13 * 16 + 14;
	pBuffer[(fromY - 1) * nScreenWidth + fromX + 23] = L'█';
	pColor[(fromY - 1) * nScreenWidth + fromX + 23] = (pColor[(fromY - 1) * nScreenWidth + fromX + 23] / 16) * 16 + 13;
	pBuffer[fromY * nScreenWidth + fromX + 23] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 23] = 14 * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 23] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 23] = 13 * 16 + 14;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 23] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 23] = 13 * 16 + 14;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 23] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 23] = 14 * 16 + 13;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 23] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + fromX + 23] = (pColor[(fromY + 4) * nScreenWidth + fromX + 23] / 16) * 16 + 13;

	pBuffer[(fromY - 2) * nScreenWidth + fromX + 24] = L'▄';
	pColor[(fromY - 2) * nScreenWidth + fromX + 24] = (pColor[(fromY - 2) * nScreenWidth + fromX + 24] / 16) * 16 + 14;
	pBuffer[(fromY - 1) * nScreenWidth + fromX + 24] = L'█';
	pColor[(fromY - 1) * nScreenWidth + fromX + 24] = (pColor[(fromY - 1) * nScreenWidth + fromX + 24] / 16) * 16 + 13;
	pBuffer[fromY * nScreenWidth + fromX + 24] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 24] = 14 * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 24] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 24] = 13 * 16 + 14;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 24] = L'█';
	pColor[(fromY + 2) * nScreenWidth + fromX + 24] = (pColor[(fromY + 2) * nScreenWidth + fromX + 24] / 16) * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 24] = L'█';
	pColor[(fromY + 3) * nScreenWidth + fromX + 24] = (pColor[(fromY + 5) * nScreenWidth + fromX + 24] / 16) * 16 + 14;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 24] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + fromX + 24] = (pColor[(fromY + 4) * nScreenWidth + fromX + 24] / 16) * 16 + 13;

	pBuffer[(fromY - 1) * nScreenWidth + fromX + 25] = L'█';
	pColor[(fromY - 1) * nScreenWidth + fromX + 25] = (pColor[(fromY - 1) * nScreenWidth + fromX + 25] / 16) * 16 + 13;
	pBuffer[fromY * nScreenWidth + fromX + 25] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 25] = 13 * 16 + 14;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 25] = L'█';
	pColor[(fromY + 1) * nScreenWidth + fromX + 25] = (pColor[(fromY + 1) * nScreenWidth + fromX + 25] / 16) * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 25] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 25] = 14 * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 25] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 25] = 13 * 16 + 14;
	pBuffer[(fromY + 4) * nScreenWidth + fromX + 25] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + fromX + 25] = (pColor[(fromY + 4) * nScreenWidth + fromX + 25] / 16) * 16 + 13;

	pBuffer[(fromY - 1) * nScreenWidth + fromX + 26] = L'▄';
	pColor[(fromY - 1) * nScreenWidth + fromX + 26] = (pColor[(fromY - 1) * nScreenWidth + fromX + 26] / 16) * 16 + 13;
	pBuffer[fromY * nScreenWidth + fromX + 26] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 26] = 13 * 16 + 14;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 26] = L'█';
	pColor[(fromY + 1) * nScreenWidth + fromX + 26] = (pColor[(fromY + 1) * nScreenWidth + fromX + 26] / 16) * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 26] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 26] = 14 * 16 + 13;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 26] = L'▄';
	pColor[(fromY + 3) * nScreenWidth + fromX + 26] = 13 * 16 + 14;

	pBuffer[fromY * nScreenWidth + fromX + 27] = L'▄';
	pColor[fromY * nScreenWidth + fromX + 27] = (pColor[fromY * nScreenWidth + fromX + 27] / 16) * 16 + 13;
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 27] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 27] = 14 * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 27] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 27] = 13 * 16 + 14;
	pBuffer[(fromY + 3) * nScreenWidth + fromX + 27] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + fromX + 27] = (pColor[(fromY + 3) * nScreenWidth + fromX + 27] / 16) * 16 + 13;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + 28] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 28] = 14 * 16 + 13;
	pBuffer[(fromY + 2) * nScreenWidth + fromX + 28] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + fromX + 28] = 13 * 16 + 14;
}
void drawFox(int fromX, int fromY)
{
	//col 1
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 1)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 1)] = (pColor[(fromY + 2) * nScreenWidth + fromX + 1] / 16) * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 1)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 1)] = 2 * 16 + 10;

	//col 2
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 2)] = 2 * 16 + 10;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 2)] = 10 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 2)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 2)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 2)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 2)] = (pColor[(fromY + 4) * nScreenWidth + fromX + 2] / 16) * 16 + 2;

	//col 3
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 1) * nScreenWidth + fromX + 3] / 16) * 16 + 10;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 3)] = 10 * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 3)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 3)] = 2 * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 3)] = L'▄';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 6) * nScreenWidth + fromX + 3] / 16) * 16 + 7;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 3)] = 10 * 16 + 7;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 3)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 3)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 3)] = 6 * 16 + 6;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 3)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 3)] = (pColor[(fromY + 10) * nScreenWidth + fromX + 3] / 16) * 16 + 6;

	//col 4
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 4)] = 10 * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 4)] = 2 * 16;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 4)] = 2 * 16 + 2;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 4)] = 7 * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 4)] = 7 * 16 + 7;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 4)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 4)] = 10 * 16 + 7;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 4)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 4)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 4)] = 6 * 16 + 6;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 4)] = 6 * 16 + 6;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 4)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 4)] = 6 * 16 + 6;

	//col 5
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 5)] = 10 * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 5)] = 2 * 16 + 10;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 5)] = 2 * 16;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 5)] = 7 * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 5)] = 7 * 16 + 7;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 5)] = 7 * 16 + 7;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 5)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 5)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 5)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 5)] = 6 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 5)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 5)] = (pColor[(fromY + 11) * nScreenWidth + fromX + 5] / 16) * 16 + 6;

	//col 6
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 6)] = 10 * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 6)] = 2 * 16 + 10;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 6)] = 2 * 16;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 6)] = 7 * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 6)] = 7 * 16 + 7;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 6)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 6)] = 10 * 16 + 7;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 6)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 6)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 6)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 6)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 6)] = 10 * 16 + 10;

	//col 7
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 7)] = 2 * 16;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 7)] = 2 * 16 + 2;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 7)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 7)] = 7 * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 7)] = 7 * 16 + 7;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 7)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 7)] = 10 * 16 + 10;

	//col 8
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 8)] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 8)] = (pColor[(fromY + 1) * nScreenWidth + fromX + 8] / 16) * 16 + 10;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 8)] = 10 * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 8)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 8)] = 2 * 16 + 2;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 8)] = L'▀';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 8)] = 7 * 16 + 2;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 8)] = 10 * 16 + 10;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 8)] = 10 * 16 + 10;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 8)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 8)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 8)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 8)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 8)] = 10 * 16 + 10;

	//col 9
	pBuffer[(fromY + 1) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + (fromX + 9)] = 2 * 16 + 10;
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 9)] = 10 * 16 + 2;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 9)] = 2 * 16 + 2;
	pBuffer[(fromY + 4) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 4) * nScreenWidth + (fromX + 9)] = 2 * 16 + 2;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 9)] = 10 * 16 + 10;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 9)] = 10 * 16 + 10;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 9)] = 10 * 16 + 10;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 9)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 9)] = 7 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 9)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 9)] = 7 * 16 + 7;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 9)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 11) * nScreenWidth + fromX + 9] / 16) * 16 + 7;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 9)] = L'▄';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 9)] = (pColor[(fromY + 12) * nScreenWidth + fromX + 9] / 16) * 16 + 10;

	//col 10
	pBuffer[(fromY + 2) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 2) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 2) * nScreenWidth + fromX + 10] / 16) * 16 + 10;
	pBuffer[(fromY + 3) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 3) * nScreenWidth + (fromX + 10)] = 2 * 16 + 10;
	pBuffer[(fromY + 5) * nScreenWidth + (fromX + 10)] = L'▄';
	pColor[(fromY + 5) * nScreenWidth + (fromX + 10)] = (pColor[(fromY + 5) * nScreenWidth + fromX + 10] / 16) * 16 + 10;
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 10)] = 10 * 16 + 10;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 10)] = 10 * 16 + 10;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 10)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 10)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 10)] = 7 * 16 + 7;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 10)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 10)] = 7 * 16 + 7;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 10)] = L'▀';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 10)] = 10 * 16 + 10;

	//col 11
	pBuffer[(fromY + 6) * nScreenWidth + (fromX + 11)] = L'▄';
	pColor[(fromY + 6) * nScreenWidth + (fromX + 11)] = (pColor[(fromY + 6) * nScreenWidth + fromX + 11] / 16) * 16 + 10;
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 11)] = 10 * 16 + 10;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 11)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 11)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 11)] = L'▀';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 11)] = 7 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 11)] = 7 * 16 + 7;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 11)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 11)] = 10 * 16 + 10;

	//col 12
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 12)] = 10 * 16 + 10;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 12)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 12)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 12)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 12)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 12)] = 10 * 16 + 7;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 12)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 12)] = 10 * 16 + 10;

	//col 13
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 13)] = L'▀';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 13)] = 10 * 16 + 7;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 13)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 13)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 13)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 13)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 13)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 13)] = 10 * 16 + 10;

	//col 14
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 14)] = 7 * 16 + 7;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 14)] = 10 * 16 + 10;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 14)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 14)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 14)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 14)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 14)] = 10 * 16 + 10;

	//col 15
	pBuffer[(fromY + 7) * nScreenWidth + (fromX + 15)] = L'▄';
	pColor[(fromY + 7) * nScreenWidth + (fromX + 15)] = (pColor[(fromY + 7) * nScreenWidth + fromX + 15] / 16) * 16 + 7;
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 15)] = L'▀';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 15)] = 10 * 16 + 7;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 15)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 15)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 15)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 15)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 15)] = 10 * 16 + 10;

	//col 16
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 16)] = L'▀';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 16)] = 10 * 16 + 7;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 16)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 16)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 16)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 16)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 16)] = 10 * 16 + 10;

	//col 17
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 17)] = 7 * 16 + 7;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 17)] = 10 * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 17)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 17)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 17)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 17)] = 10 * 16 + 10;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 17)] = L'▀';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 17)] = 3 * 16 + 2;

	//col 18
	pBuffer[(fromY + 8) * nScreenWidth + (fromX + 18)] = L'▄';
	pColor[(fromY + 8) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 8) * nScreenWidth + fromX + 18] / 16) * 16 + 7;
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 18)] = L'▀';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 18)] = 10 * 16 + 7;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 18)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 18)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 18)] = (pColor[(fromY + 11) * nScreenWidth + fromX + 18] / 16) * 16 + 10;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 18)] = L'▀';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 18)] = 2 * 16 + 10;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 18)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 18)] = 2 * 16 + 2;

	//col 19
	pBuffer[(fromY + 9) * nScreenWidth + (fromX + 19)] = L'▄';
	pColor[(fromY + 9) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 9) * nScreenWidth + fromX + 19] / 16) * 16 + 10;
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 19)] = 10 * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 19)] = L'▀';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 19)] = (pColor[(fromY + 11) * nScreenWidth + fromX + 19] / 16) * 16 + 10;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 19)] = 10 * 16 + 10;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 19)] = 2 * 16 + 2;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 19)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 19)] = 2 * 16 + 2;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 19)] = L'▀';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 19)] = 4 * 16 + 2;

	//col 20
	pBuffer[(fromY + 10) * nScreenWidth + (fromX + 20)] = L'▄';
	pColor[(fromY + 10) * nScreenWidth + (fromX + 20)] = (pColor[(fromY + 10) * nScreenWidth + fromX + 20] / 16) * 16 + 10;
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 20)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 20)] = L'▄';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 20)] = (pColor[(fromY + 12) * nScreenWidth + fromX + 20] / 16) * 16 + 10;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 20)] = L'▀';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 20)] = 2 * 16 + 10;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 20)] = 2 * 16 + 2;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 20)] = 2 * 16 + 2;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 20)] = L'█';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 20)] = 2 * 16 + 2;

	//col 21
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 21)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 21)] = 10 * 16 + 10;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 21)] = 10 * 16 + 10;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 21)] = 2 * 16 + 2;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 21)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 21)] = 2 * 16 + 2;
	pBuffer[(fromY + 16) * nScreenWidth + (fromX + 21)] = L'▀';
	pColor[(fromY + 16) * nScreenWidth + (fromX + 21)] = 4 * 16 + 2;

	//col 22
	pBuffer[(fromY + 11) * nScreenWidth + (fromX + 22)] = L'█';
	pColor[(fromY + 11) * nScreenWidth + (fromX + 22)] = 10 * 16 + 10;
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 22)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 22)] = 10 * 16 + 10;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 22)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 22)] = 10 * 16 + 10;
	pBuffer[(fromY + 14) * nScreenWidth + (fromX + 22)] = L'▀';
	pColor[(fromY + 14) * nScreenWidth + (fromX + 22)] = 2 * 16 + 10;
	pBuffer[(fromY + 15) * nScreenWidth + (fromX + 22)] = L'█';
	pColor[(fromY + 15) * nScreenWidth + (fromX + 22)] = 2 * 16 + 2;

	//col 23
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 23)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 23)] = 10 * 16 + 10;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 23)] = L'█';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 23)] = 10 * 16 + 10;

	//col 24
	pBuffer[(fromY + 12) * nScreenWidth + (fromX + 24)] = L'█';
	pColor[(fromY + 12) * nScreenWidth + (fromX + 24)] = 10 * 16 + 10;
	pBuffer[(fromY + 13) * nScreenWidth + (fromX + 24)] = L'▀';
	pColor[(fromY + 13) * nScreenWidth + (fromX + 24)] = 11 * 16 + 10;
}

void drawNotiBoard(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, int height)
{
	int realheight = height / 2;
	//BO GOC TREN
	for (int i = fromX + 3; i <= fromX + width - 4; i++)
	{
		pBuffer[fromY * nScreenWidth + i] = L'▄';
		pColor[fromY * nScreenWidth + i] = (pColor[fromY * nScreenWidth + i] / 16) * 16 + 5;
	}
	pBuffer[fromY * nScreenWidth + fromX + width - 3] = L'▄';
	pColor[fromY * nScreenWidth + fromX + width - 3] = (pColor[fromY * nScreenWidth + fromX + width - 3] / 16) * 16 + 4;

	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY + 1) * nScreenWidth + i] = L' ';
		pColor[(fromY + 1) * nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY + 1) * nScreenWidth + fromX + width - 2] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + 1] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + 1) * nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + width - 1] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	pBuffer[(fromY + 2) * nScreenWidth + fromX] = L' ';
	pColor[(fromY + 2) * nScreenWidth + fromX] = 5 * 16;

	pBuffer[(fromY + 2) * nScreenWidth + fromX + width] = L' ';
	pColor[(fromY + 2) * nScreenWidth + fromX + width] = 4 * 16;

	for (int i = fromX + 1; i <= fromX + width - 1; i++)
	{
		pBuffer[(fromY + 2) * nScreenWidth + i] = L' ';
		pColor[(fromY + 2) * nScreenWidth + i] = 5 * 16;
	}

	//BO GOC DUOI

	for (int i = fromX + 1; i <= fromX + width - 1; i++)
	{
		pBuffer[(fromY + realheight - 2) * nScreenWidth + i] = L' ';
		pColor[(fromY + realheight - 2) * nScreenWidth + i] = 5 * 16;
	}

	pBuffer[(fromY + realheight - 2) * nScreenWidth + fromX] = L' ';
	pColor[(fromY + realheight - 2) * nScreenWidth + fromX] = 5 * 16;

	pBuffer[(fromY + realheight - 2) * nScreenWidth + fromX + width] = L' ';
	pColor[(fromY + realheight - 2) * nScreenWidth + fromX + width] = 4 * 16;

	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY + realheight - 1) * nScreenWidth + i] = L' ';
		pColor[(fromY + realheight - 1) * nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	for (int i = fromX + 3; i <= fromX + width - 4; i++)
	{
		pBuffer[(fromY + realheight) * nScreenWidth + i] = L'▀';
		pColor[(fromY + realheight) * nScreenWidth + i] = (pColor[(fromY + realheight) * nScreenWidth + i] / 16) * 16 + 5;
	}
	pBuffer[(fromY + realheight) * nScreenWidth + fromX + width - 3] = L'▀';
	pColor[(fromY + realheight) * nScreenWidth + fromX + width - 3] = (pColor[(fromY + realheight) * nScreenWidth + fromX + width - 3] / 16) * 16 + 4;

	//PHAN VIET NOI DUNG

	for (int i = fromY + 3; i <= fromY + realheight - 3; i++)
		for (int j = fromX; j <= fromX + width - 1; j++)
		{
			pBuffer[i * nScreenWidth + j] = L' ';
			pColor[i * nScreenWidth + j] = 5 * 16;
		}
	for (int i = fromY + 3; i <= fromY + realheight - 3; i++)
	{
		pBuffer[i * nScreenWidth + fromX + width] = L' ';
		pColor[i * nScreenWidth + fromX + width] = 4 * 16;
	}
}
void drawNotiBoard2(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, int height)
{
	int realheight = height / 2;
	realheight = realheight - (1 - realheight % 2);
	//BO GOC TREN


	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY)*nScreenWidth + i] = L' ';
		pColor[(fromY)*nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY)*nScreenWidth + fromX + width - 2] = L'▄';
	pColor[(fromY)*nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY)*nScreenWidth + fromX + 1] = L'▄';
	pColor[(fromY)*nScreenWidth + fromX + 1] = (pColor[(fromY)*nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY)*nScreenWidth + fromX + width - 1] = L'▄';
	pColor[(fromY)*nScreenWidth + fromX + width - 1] = (pColor[(fromY)*nScreenWidth + fromX + width - 1] / 16) * 16 + 4;


	//BO GOC DUOI
	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY + realheight - 1) * nScreenWidth + i] = L' ';
		pColor[(fromY + realheight - 1) * nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	//PHAN VIET NOI DUNG

	for (int i = fromY + 1; i <= fromY + realheight - 2; i++)
		for (int j = fromX; j <= fromX + width - 1; j++)
		{
			pBuffer[i * nScreenWidth + j] = L' ';
			pColor[i * nScreenWidth + j] = 5 * 16;
		}
	for (int i = fromY + 1; i <= fromY + realheight - 2; i++)
	{
		pBuffer[i * nScreenWidth + fromX + width] = L' ';
		pColor[i * nScreenWidth + fromX + width] = 4 * 16;
	}
}
void drawNotiBoard(int fromX, int fromY, int width, int height)
{
	int realheight = height / 2;
	//BO GOC TREN
	for (int i = fromX + 3; i <= fromX + width - 4; i++)
	{
		pBuffer[fromY * nScreenWidth + i] = L'▄';
		pColor[fromY * nScreenWidth + i] = (pColor[fromY * nScreenWidth + i] / 16) * 16 + 5;
	}
	pBuffer[fromY * nScreenWidth + fromX + width - 3] = L'▄';
	pColor[fromY * nScreenWidth + fromX + width - 3] = (pColor[fromY * nScreenWidth + fromX + width - 3] / 16) * 16 + 4;

	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY + 1) * nScreenWidth + i] = L' ';
		pColor[(fromY + 1) * nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY + 1) * nScreenWidth + fromX + width - 2] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + 1] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + 1) * nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + width - 1] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	pBuffer[(fromY + 2) * nScreenWidth + fromX] = L' ';
	pColor[(fromY + 2) * nScreenWidth + fromX] = 5 * 16;

	pBuffer[(fromY + 2) * nScreenWidth + fromX + width] = L' ';
	pColor[(fromY + 2) * nScreenWidth + fromX + width] = 4 * 16;

	for (int i = fromX + 1; i <= fromX + width - 1; i++)
	{
		pBuffer[(fromY + 2) * nScreenWidth + i] = L' ';
		pColor[(fromY + 2) * nScreenWidth + i] = 5 * 16;
	}

	//BO GOC DUOI

	for (int i = fromX + 1; i <= fromX + width - 1; i++)
	{
		pBuffer[(fromY + realheight - 2) * nScreenWidth + i] = L' ';
		pColor[(fromY + realheight - 2) * nScreenWidth + i] = 5 * 16;
	}

	pBuffer[(fromY + realheight - 2) * nScreenWidth + fromX] = L' ';
	pColor[(fromY + realheight - 2) * nScreenWidth + fromX] = 5 * 16;

	pBuffer[(fromY + realheight - 2) * nScreenWidth + fromX + width] = L' ';
	pColor[(fromY + realheight - 2) * nScreenWidth + fromX + width] = 4 * 16;

	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY + realheight - 1) * nScreenWidth + i] = L' ';
		pColor[(fromY + realheight - 1) * nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	for (int i = fromX + 3; i <= fromX + width - 4; i++)
	{
		pBuffer[(fromY + realheight) * nScreenWidth + i] = L'▀';
		pColor[(fromY + realheight) * nScreenWidth + i] = (pColor[(fromY + realheight) * nScreenWidth + i] / 16) * 16 + 5;
	}
	pBuffer[(fromY + realheight) * nScreenWidth + fromX + width - 3] = L'▀';
	pColor[(fromY + realheight) * nScreenWidth + fromX + width - 3] = (pColor[(fromY + realheight) * nScreenWidth + fromX + width - 3] / 16) * 16 + 4;

	//PHAN VIET NOI DUNG

	for (int i = fromY + 3; i <= fromY + realheight - 3; i++)
		for (int j = fromX; j <= fromX + width - 1; j++)
		{
			pBuffer[i * nScreenWidth + j] = L' ';
			pColor[i * nScreenWidth + j] = 5 * 16;
		}
	for (int i = fromY + 3; i <= fromY + realheight - 3; i++)
	{
		pBuffer[i * nScreenWidth + fromX + width] = L' ';
		pColor[i * nScreenWidth + fromX + width] = 4 * 16;
	}
}
void drawNotiBoard2(int fromX, int fromY, int width, int height)
{
	int realheight = height / 2;
	realheight = realheight - (1 - realheight % 2);
	//BO GOC TREN


	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY)*nScreenWidth + i] = L' ';
		pColor[(fromY)*nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY)*nScreenWidth + fromX + width - 2] = L'▄';
	pColor[(fromY)*nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY)*nScreenWidth + fromX + 1] = L'▄';
	pColor[(fromY)*nScreenWidth + fromX + 1] = (pColor[(fromY)*nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY)*nScreenWidth + fromX + width - 1] = L'▄';
	pColor[(fromY)*nScreenWidth + fromX + width - 1] = (pColor[(fromY)*nScreenWidth + fromX + width - 1] / 16) * 16 + 4;


	//BO GOC DUOI
	for (int i = fromX + 2; i <= fromX + width - 3; i++)
	{
		pBuffer[(fromY + realheight - 1) * nScreenWidth + i] = L' ';
		pColor[(fromY + realheight - 1) * nScreenWidth + i] = 5 * 16;
	}
	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 2] = 4 * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + 1] / 16) * 16 + 5;

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	//PHAN VIET NOI DUNG

	for (int i = fromY + 1; i <= fromY + realheight - 2; i++)
		for (int j = fromX; j <= fromX + width - 1; j++)
		{
			pBuffer[i * nScreenWidth + j] = L' ';
			pColor[i * nScreenWidth + j] = 5 * 16;
		}
	for (int i = fromY + 1; i <= fromY + realheight - 2; i++)
	{
		pBuffer[i * nScreenWidth + fromX + width] = L' ';
		pColor[i * nScreenWidth + fromX + width] = 4 * 16;
	}
}
void drawNotiBoard3(int fromX, int fromY, int width, int height)
{
	int realheight = height / 2;
	realheight = realheight - (1 - realheight % 2);
	//BO GOC TREN


	for (int i = fromX + 1; i <= fromX + width - 2; i++)
	{
		pBuffer[(fromY)*nScreenWidth + i] = L'▄';
		pColor[(fromY)*nScreenWidth + i] = (pColor[(fromY)*nScreenWidth + i] / 16) * 16 + 5;
	}
	pBuffer[(fromY)*nScreenWidth + fromX + width - 1] = L'▄';
	pColor[(fromY)*nScreenWidth + fromX + width - 1] = (pColor[(fromY)*nScreenWidth + fromX + width - 1] / 16) * 16 + 4;


	//BO GOC DUOI
	for (int i = fromX + 1; i <= fromX + width - 2; i++)
	{
		pBuffer[(fromY + realheight - 1) * nScreenWidth + i] = L'▀';
		pColor[(fromY + realheight - 1) * nScreenWidth + i] = (pColor[(fromY + realheight - 1) * nScreenWidth + i] / 16) * 16 + 5;
	}

	pBuffer[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = L'▀';
	pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + realheight - 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + 4;

	//PHAN VIET NOI DUNG

	for (int i = fromY + 1; i <= fromY + realheight - 2; i++)
		for (int j = fromX; j <= fromX + width - 1; j++)
		{
			pBuffer[i * nScreenWidth + j] = L' ';
			pColor[i * nScreenWidth + j] = 5 * 16;
		}
	for (int i = fromY + 1; i <= fromY + realheight - 2; i++)
	{
		pBuffer[i * nScreenWidth + fromX + width] = L' ';
		pColor[i * nScreenWidth + fromX + width] = 4 * 16;
	}
}
void drawEnterNameBoard(wstring title, int fromX, int fromY, int width, int height)
{
	drawNotiBoard(fromX, fromY, width, height);
	Text(title, 5 * 16 + 2, fromX + width / 2 - title.length() / 2, fromY + 1);
	Text(L"*Less than 20 characters", 5 * 16 + 2, fromX + 1, fromY + 3);
	Text(L"Enter: ", 5 * 16 + 2, fromX + 1, fromY + 4);
	Text(L"OK", 16 * 5 + 2, fromX + 3 + (width / 2) / 2 - 1, fromY + height / 2 - 1);
	Text(L"BACK", 16 * 5 + 2, fromX + width / 2 + (width / 2) / 2 - 2, fromY + height / 2 - 1);
	Text(L"|", 5 * 16 + 4, fromX + width / 2, fromY + height / 2 - 1);
	Display();
}

void Background()
{
	drawCloud(5, 0);
	drawCloud(85, 0);

	drawGrass(0, 26);

	drawBushes(0, 23);
	drawBushes(97, 23);
	drawBushes(35, 23);
	drawBushes(58, 23);

	drawTree(1, 6);
	drawTree(94, 6);

	drawWease(18, 16);
	drawFox(74, 13);
}
void BackgroundOngame()
{
	drawGrass(0, 26);
	drawBushes(0, 23);
	drawBushes(98, 23);
	drawBushes(84, 23);

	drawNotiBoard(4, 3, 25, 17);
	drawNotiBoard(88, 3, 25, 17);

	//VE BANG ROUND
	drawNotiBoard(20, 20, 14, 8);
	for (int i = 20; i <= 24; i++)
		for (int j = 20; j <= 23; j++)
		{
			pBuffer[i * nScreenWidth + j] = L' ';
			pColor[i * nScreenWidth + j] = 1 * 16;
		}
	for (int i = 20; i <= 20 + 14; i++)
	{
		pBuffer[20 * nScreenWidth + i] = L' ';
		pColor[20 * nScreenWidth + i] = 1 * 16;
	}
	for (int i = 20; i <= 20 + 14; i++)
	{
		pBuffer[24 * nScreenWidth + i] = L' ';
		pColor[24 * nScreenWidth + i] = 1 * 16;
	}
	for (int i = 24; i <= 25; i++)
	{
		pBuffer[i * nScreenWidth + 28] = L' ';
		pColor[i * nScreenWidth + 28] = 5 * 16;
	}

	//VE COT BANG ROUND
	for (int i = 24; i <= 25; i++)
	{
		pBuffer[i * nScreenWidth + 28] = L' ';
		pColor[i * nScreenWidth + 28] = 5 * 16;
	}
	for (int i = 24; i <= 25; i++)
	{
		pBuffer[i * nScreenWidth + 29] = L' ';
		pColor[i * nScreenWidth + 29] = 4 * 16;
	}

	drawFox(85, 13);
	drawWease(1, 16);
}
void Backgroundsub()
{
	drawGrass(0, 26);

	drawCloud(5, 0);
	drawCloud(85, 0);

	drawBushes(0, 23);
	drawBushes(97, 23);
	drawBushes(35, 23);
	drawBushes(58, 23);

	drawTree(1, 6);
	drawTree(94, 6);

	drawFox(89, 13);
	drawWease(1, 16);
}

void printMatrix() {
	for (int i = 0; i < BOARD_SIZE; i++)
	{
		for (int j = 0; j < BOARD_SIZE; j++)
		{
			if (CARO_BOARD[i][j] == -1)
				Text(L"X", 1 * 16 + 3, 37 + 4 * i, 2 + 2 * j);
			else if (CARO_BOARD[i][j] == 1)
				Text(L"O", 1 * 16 + 6, 37 + 4 * i, 2 + 2 * j);
			else
				Text(L" ", 1 * 16 + 8, 37 + 4 * i, 2 + 2 * j);
		}
	}
	Display();
}

void DrawTab(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, wstring title)
{

	for (int i = fromX + 2; i <= fromX + width - 2; i++)
	{
		pBuffer[(fromY)*nScreenWidth + i] = L'▄';
		pColor[(fromY)*nScreenWidth + i] = (pColor[(fromY)*nScreenWidth + i] / 16) * 16 + 5;
	}

	for (int i = fromX + 1; i <= fromX + width - 1; i++)
	{
		pBuffer[(fromY + 1) * nScreenWidth + i] = L' ';
		pColor[(fromY + 1) * nScreenWidth + i] = 5 * 16;
	}

	pBuffer[(fromY + 1) * nScreenWidth + fromX] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX] = (pColor[(fromY + 1) * nScreenWidth + fromX] / 16) * 16 + 5;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + width] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + width] = (pColor[(fromY + 1) * nScreenWidth + fromX + width] / 16) * 16 + 5;

	Text(pBuffer, pColor, title, 5 * 16 + 2, fromX + width / 2 - title.length() / 2, fromY + 1);
}
void ColorTabFrame(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width, WORD color)
{
	for (int i = fromX + 2; i <= fromX + width - 2; i++)
	{
		pBuffer[(fromY)*nScreenWidth + i] = L'▄';
		pColor[(fromY)*nScreenWidth + i] = (pColor[(fromY)*nScreenWidth + i] / 16) * 16 + color;
	}
	pBuffer[(fromY + 1) * nScreenWidth + fromX + 1] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + fromX + 1] = (pColor[(fromY + 1) * nScreenWidth + fromX + 1] / 16) * 16 + color;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + width - 1] = L'▀';
	pColor[(fromY + 1) * nScreenWidth + fromX + width - 1] = (pColor[(fromY + 1) * nScreenWidth + fromX + width - 1] / 16) * 16 + color;

	pBuffer[(fromY + 1) * nScreenWidth + fromX] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX] = (pColor[(fromY + 1) * nScreenWidth + fromX] / 16) * 16 + color;

	pBuffer[(fromY + 1) * nScreenWidth + fromX + width] = L'▄';
	pColor[(fromY + 1) * nScreenWidth + fromX + width] = (pColor[(fromY + 1) * nScreenWidth + fromX + width] / 16) * 16 + color;
}
void KeyboardGuide(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width)
{
	//Xoa vien tab Rule
	ColorTabFrame(pBuffer, pColor, fromX + width, fromY, width, 5);
	//Ve lai phan frame cua bang duoi tab Rule
	for (int i = fromX + width; i <= fromX + 2 * width; i++)
	{
		pBuffer[(fromY + 2) * nScreenWidth + i] = L'▀';
		pColor[(fromY + 2) * nScreenWidth + i] = (pColor[(fromY + 2) * nScreenWidth + i] / 16) * 16 + 4;
	}
	//Vien tab KeyboardGuide
	ColorTabFrame(pBuffer, pColor, fromX, fromY, width, 4);
	//Xoa phan frame cua bang duoi tab KeyboardGuide
	for (int i = fromX; i <= fromX + width; i++)
	{
		pBuffer[(fromY + 2) * nScreenWidth + i] = L' ';
		pColor[(fromY + 2) * nScreenWidth + i] = 5 * 16 + 5;
	}
	pBuffer[(fromY + 2) * nScreenWidth + fromX] = L' ';
	pColor[(fromY + 2) * nScreenWidth + fromX] = 4 * 16 + 4;
}
void Rule(wchar_t* pBuffer, WORD* pColor, int fromX, int fromY, int width)
{
	//Xoa vien tab Keyboard Guide
	ColorTabFrame(pBuffer, pColor, fromX - width, fromY, width, 5);
	//Ve lai phan frame cua bang duoi tab Keyboard Guide
	for (int i = fromX - width; i <= fromX; i++)
	{
		pBuffer[(fromY + 2) * nScreenWidth + i] = L'▀';
		pColor[(fromY + 2) * nScreenWidth + i] = (pColor[(fromY + 2) * nScreenWidth + i] / 16) * 16 + 4;
	}
	//Vien tab Rule
	ColorTabFrame(pBuffer, pColor, fromX, fromY, width, 4);
	//Xoa phan frame cua bang duoi tab rule
	for (int i = fromX; i <= fromX + width; i++)
	{
		pBuffer[(fromY + 2) * nScreenWidth + i] = L' ';
		pColor[(fromY + 2) * nScreenWidth + i] = 5 * 16 + 5;
	}
}

void Blinking(vector<wstring> wsContent, int color1, int color2, int color3, int fromX, int fromY)
{
	ClearScreen(1, 0);
	drawGrass(0, 26);

	if (sound)
		playSound(2);

	char tmp{};
	for (int i = 0; i < 10; i++)
	{
		if ((tmp = GetAsyncKeyState(key[4]) < 0) || (tmp = GetAsyncKeyState(key[11]) < 0))
		{
			while (tmp)
			{
				tmp = GetAsyncKeyState(key[4]) < 0;
				tmp = GetAsyncKeyState(key[11]) < 0;
			}
			mciSendString(L"close wav", NULL, 0, NULL);
			break;
		}
		DrawObject(wsContent, 1 * 16 + color1, fromX, fromY);
		Display();
		Sleep(100);
		if ((tmp = GetAsyncKeyState(key[4]) < 0) || (tmp = GetAsyncKeyState(key[11]) < 0))
		{
			while (tmp)
			{
				tmp = GetAsyncKeyState(key[4]) < 0;
				tmp = GetAsyncKeyState(key[11]) < 0;
			}
			mciSendString(L"close wav", NULL, 0, NULL);
			break;
		}
		DrawObject(wsContent, 1 * 16 + color2, fromX, fromY);
		Display();
		Sleep(100);
		if ((tmp = GetAsyncKeyState(key[4]) < 0) || (tmp = GetAsyncKeyState(key[11]) < 0))
		{
			while (tmp)
			{
				tmp = GetAsyncKeyState(key[4]) < 0;
				tmp = GetAsyncKeyState(key[11]) < 0;
			}
			mciSendString(L"close wav", NULL, 0, NULL);
			break;
		}
		DrawObject(wsContent, 1 * 16 + color3, fromX, fromY);
		Display();
		Sleep(100);

		if (i == 2)
		{
			drawBushes(0, 23);
			drawBushes(97, 23);
		}
		if (i == 4)
		{
			drawBushes(35, 23);
			drawBushes(58, 23);
		}
		if (i == 6)
		{
			drawTree(1, 6);
			drawTree(94, 6);
		}
		if (i == 8)
		{
			drawCloud(5, 0);
			drawCloud(85, 0);
			drawWease(18, 16);
			drawFox(74, 13);
		}
	}
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
}
void Blinking(wchar_t* pBuffer, WORD* pColor, vector<wstring> wsContent, int color1, int color2, int color3, int fromX, int fromY)
{
	if (sound)
		playSound(2);

	char tmp{};
	for (int i = 0; i < 10; i++)
	{
		if ((tmp = GetAsyncKeyState(key[4]) < 0) || (tmp = GetAsyncKeyState(key[11]) < 0))
		{
			while (tmp)
			{
				tmp = GetAsyncKeyState(key[4]) < 0;
				tmp = GetAsyncKeyState(key[11]) < 0;
			}
			mciSendString(L"close wav", NULL, 0, NULL);
			break;
		}
		DrawObject(pBuffer, pColor, wsContent, 1 * 16 + color1, fromX, fromY);
		Display(pBuffer, pColor, fromX, fromY, fromX + wsContent[0].size() - 1, fromY + 5);
		Sleep(100);
		if ((tmp = GetAsyncKeyState(key[4]) < 0) || (tmp = GetAsyncKeyState(key[11]) < 0))
		{
			while (tmp)
			{
				tmp = GetAsyncKeyState(key[4]) < 0;
				tmp = GetAsyncKeyState(key[11]) < 0;
			}
			mciSendString(L"close wav", NULL, 0, NULL);
			break;
		}
		DrawObject(pBuffer, pColor, wsContent, 1 * 16 + color2, fromX, fromY);
		Display(pBuffer, pColor, fromX, fromY, fromX + wsContent[0].size() - 1, fromY + 5);
		Sleep(100);
		if ((tmp = GetAsyncKeyState(key[4]) < 0) || (tmp = GetAsyncKeyState(key[11]) < 0))
		{
			while (tmp)
			{
				tmp = GetAsyncKeyState(key[4]) < 0;
				tmp = GetAsyncKeyState(key[11]) < 0;
			}
			mciSendString(L"close wav", NULL, 0, NULL);
			break;
		}
		DrawObject(pBuffer, pColor, wsContent, 1 * 16 + color3, fromX, fromY);
		Display(pBuffer, pColor, fromX, fromY, fromX + wsContent[0].size() - 1, fromY + 5);
		Sleep(100);
	}
	FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
}


