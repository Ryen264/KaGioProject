﻿#pragma once
#include "Global.h"
#include "View.h"
#include "Control.h"
using namespace std;

int enterName(wchar_t* pBuffer, WORD* pColor, wstring& name, wstring title, int fromX, int fromY);
bool checkInWstr(wstring wstr, vector<wstring> list);
int enterNameFile(wchar_t* pBuffer, WORD* pColor, wstring& name, wstring title, int fromX, int fromY);
int save_game(wchar_t* pBuffer, WORD* pColor, int level, int switch_file);
int Pause(int level, int switch_file);

static _POINT cheo1(_POINT move, int i, bool isIncrease);
static _POINT cheo2(_POINT move, int i, bool isIncrease);
static _POINT ngang(_POINT move, int i, bool isIncrease);
static _POINT doc(_POINT move, int i, bool isIncrease);

static int count(_POINT move, _POINT(*direction) (_POINT, int, bool));
static bool checkInBoard(_POINT move);
static bool checkFullBoard();
static bool checkRange(_POINT move);
int checkResultBoard();

static long calAtk(_POINT move, _POINT(*direction) (_POINT, int, bool), int level);
static long calDef(_POINT move, _POINT(*direction) (_POINT, int, bool), int level);
_POINT findBest(int flag, int level);
_POINT goFirst(int level);

wstring int_to_wstr(int num);
int PlaywHum(bool switch_file);
int PlaywCom(bool switch_file, int level);

//Load file
vector<wstring> loadNamefile();
void saveNamefile(vector<wstring> listName);
void loadDatafile(wstring wstrfile, int& level);
void renamefile(int idfile, vector<wstring>& listName, const char* newName);
void deletefile(int idfile, vector<wstring>& listName);


