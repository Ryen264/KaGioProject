﻿#include "Global.h"
#include "Control.h"
using namespace std;


int main()
{
	//Setup
	Configure();

	//Intro
	Blinking(Caro, 7, 8, 9, nScreenWidth / 2 - Caro[0].length() / 2, 8);
	if (music)
		PlaySound(L"main_music.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);

	//Start app
	Menu();
	return 0;
}


