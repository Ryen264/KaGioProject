#pragma once
#include "Global.h"
#include "Model.h"
#include "View.h"

void gotoXY(int x, int y);
void playSound(int id);

void Menu();
void NewGamePage();
void LoadGamePage();
void AboutPage();

void SettingPage(wchar_t* pBuffer, WORD* pColor, int fromX = 44, int fromY = 13);
void HelpPage(wchar_t* pBuffer, WORD* pColor, int fromX = nScreenWidth / 2 - 26, int fromY = 10);
void ExitPage();
