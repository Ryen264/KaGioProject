﻿#include "Model.h"
#include "View.h"
#include "Control.h"
#include "Global.h"

#include <Windows.h>
#include <iostream>
#include <vector>
#include <string>

int main()
{
	//Cấu hình ban đầu
	Configure();


	//Tạo các mảng con trỏ
	WORD* pColor = new WORD[nScreenWidth * nScreenHeight];			//lưu màu sắc
	wchar_t* pBuffer = new wchar_t[nScreenWidth * nScreenHeight];	//lưu kí tự

	//Tạo console screen buffer
	HANDLE hConsole = CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
	//Biến hiển thị
	DWORD dwBytesWritten = 0;

	while (1)
	{
		SetConsoleActiveScreenBuffer(hConsole);

		//GET STARTED
		ClearScreen(pBuffer, pColor, 8, 9);

		//count down
		for (int i = 0; i < wsCountDown.size(); i++)
		{
			// Đưa text art vào buffer ở trung tâm màn hình, màu xanh lá
			for (int j = 0; j < wsCountDown.at(i).size(); j++)
			{
				if (i == 3)
					Text(pBuffer, pColor, wsCountDown.at(i).at(j), 8 * 16 + 4, 9, 9 + j);
				else
					Text(pBuffer, pColor, wsCountDown.at(i).at(j), 8 * 16 + 4, 18, 9 + j);
			}

			// Hiển thị
			Display(hConsole, pBuffer, pColor, dwBytesWritten);

			// Delay
			Sleep(1000);
		}

		//NEW GAME
		//Vẽ nền
		Background(pBuffer, pColor);

		//Ma trận bảng chơi
		int* pMatrix = new int[nBoardWidth * nBoardHeight];

		//Vẽ biên bảng
		Barrier(pMatrix, pBuffer);

		//Vẽ các ô Score, Line, Next
		Frame(pBuffer, L"[ SCORE ]", 17, 3, nBoardWidth, 1);
		Frame(pBuffer, L"[ LINE ]", 17, 3, nBoardWidth, 4);
		Frame(pBuffer, L"[ NEXT ]", 17, 6, nBoardWidth, 7);


		//	Bbiển tính điểm
		int nScore = 0;
		//	Vị trí in điểm
		int nScorePosX = 37;
		int nScoreComp = 10;

		//	Biến tính số hàng đã lấp
		int nLine = 0;
		//	Vị trí in số hàng đã lấp
		int nLinePosX = 37;
		int nLineComp = 10;
		//	Hiệu ứng khi lấp hàng
		std::vector<int> vLines;

		//	Biến cho game tiếp tục hay over
		bool bGameOver = false;

		//	Biến các phím di chuyển
		bool bKey[5]{{}};
		//	Biến cho xoay quân mỗi lần nhấn phím
		bool bRotateHold = true;

		//	Khối và góc quay ban đầu
		int nCurrentPiece = random(0, 6);
		int nCurrentRotation = 0;
		//	Khối tiếp theo
		int nNextPiece = random(0, 6);

		//	Tọa độ ban đầu của khối (xuất hiện ở biên trên giữa bảng chơi)
		int nCurrentX = nBoardWidth / 2 - 4;
		int nCurrentY = 0;

		//	Biến cho rơi khối mỗi game tick
		bool bForceDown = false;
		//	Biến đếm dừng mỗi game tick
		int nFrameCount = 0;
		//Số lần dừng mỗi game tick
		int nFrame = 5;

		//	Biến đếm tăng độ khó
		int nPieceCount = 0;
		//Số lần tăng độ khó
		int nLevelLimit = 2;


		//GAME LOOP
		while (bGameOver != 1)
		{
			// GAME TIMING
			Sleep(50);
			nFrameCount++;
			bForceDown = (nFrameCount == nFrame);

			// INPUT
			for (int i = 0; i < key.size(); i++)
				bKey[i] = GetAsyncKeyState(key.at(i));

			// GAME LOGIC
			int nLimit = (nCurrentPiece == 3) ? -1 : 0;	//nếu quân O thì giới hạn nhìn thấy = -1, còn lại = 0

			// Dời phải
			if (bKey[3] && nCurrentY >= nLimit
				&& CheckPiece(pMatrix, nCurrentPiece, nCurrentRotation, nCurrentX + 2, nCurrentY))
				nCurrentX += 2;

			// Dời trái
			if (bKey[1] && nCurrentY >= nLimit
				&& CheckPiece(pMatrix, nCurrentPiece, nCurrentRotation, nCurrentX - 2, nCurrentY))
				nCurrentX -= 2;

			//	Thả xuống
			if (bKey[2] && nCurrentY >= nLimit)
				while (CheckPiece(pMatrix, nCurrentPiece, nCurrentRotation, nCurrentX, nCurrentY + 1))
					nCurrentY++;

			//	Xoay khối
			if (bKey[0] && nCurrentY >= nLimit
				&& bRotateHold
				&& CheckPiece(pMatrix, nCurrentPiece, (nCurrentRotation + 1) % 4, nCurrentX, nCurrentY))
			{
				nCurrentRotation++;
				nCurrentRotation %= 4;
				bRotateHold = false;	//chỉ cho phép xoay đúng 1 lần
			}
			else
				bRotateHold = true;

			//	PAUSE
			if (bKey[4])
			{
				int nSelect = 0;

				// Tạo mảng màu độc lập
				WORD* pTmpColor = new WORD[nScreenWidth * nScreenHeight];

				for (int i = 0; i < nScreenWidth * nScreenHeight; i++)
					pTmpColor[i] = pColor[i];

				while (1)
				{
					// Thông báo tạm dừng
					Text(pBuffer, pTmpColor, L" ═════ PAUSE ════ ", 10 * 16 + 11, 2, 8);
					Text(pBuffer, pTmpColor, L"                  ", 10 * 16 + 11, 2, 9);
					Text(pBuffer, pTmpColor, L" ════════════════ ", 10 * 16 + 11, 2, 12);

					// Tạo nút lệnh và lựa chọn
					if (nSelect == 0)
					{
						Text(pBuffer, pTmpColor, L" >>  Continue  << ", 10 * 16 + 4, 2, 10);
						Text(pBuffer, pTmpColor, L"       Quit       ", 10 * 16 + 11, 2, 11);

						if (GetKeyState('S') & 0x8000)
							nSelect++;
						else if (GetKeyState(13) & 0x8000)
							break;
					}
					else
					{
						Text(pBuffer, pTmpColor, L"     Continue     ", 10 * 16 + 11, 2, 10);
						Text(pBuffer, pTmpColor, L" >>    Quit    << ", 10 * 16 + 6, 2, 11);

						if (GetKeyState('W') & 0x8000)
							nSelect--;
						else if (GetKeyState(13) & 0x8000)
							return 0;
					}

					// Hiển thị
					Display(hConsole, pBuffer, pColor, dwBytesWritten);
				}
			}

			//Rơi khối mỗi game stick
			if (bForceDown)
			{
				nFrameCount = 0;

				//Thay đổi độ khó
				if (nPieceCount == nLevelLimit && nFrame >= 5)
				{
					nFrame--;
					nPieceCount = 0;
					nLevelLimit *= 2;
				}

				if (CheckPiece(pMatrix, nCurrentPiece, nCurrentRotation, nCurrentX, nCurrentY + 1))
					nCurrentY++;
				else
					if (nCurrentY < nLimit)
					{
						//nếu khối mới không nằm trong bảng nhìn thấy thì over
						bGameOver = 1;
						break;
					}
					else
					{
						nPieceCount++;

						//Đổi màu quân đã thả xuống
						for (int i = 0; i < 8; i++)
						{
							for (int j = 0; j < 4; j++)
							{
								if (nCurrentY >= 0 && tetromino.at(nCurrentPiece).at(nCurrentRotation).at(j * 8 + i) != L'.')
								{
									if ((nCurrentY + j) % 2 == 1)
										if ((nCurrentX + i) % 4 == 1 || (nCurrentX + i) % 4 == 2)
											pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 8 * 16 + nCurrentPiece;
										else
											pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 7 * 16 + nCurrentPiece;
									else
										if ((nCurrentX + i) % 4 == 3 || (nCurrentX + i) % 4 == 0)
											pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 8 * 16 + nCurrentPiece;
										else
											pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 7 * 16 + nCurrentPiece;

									pMatrix[(nCurrentY + j) * nBoardWidth + (nCurrentX + i)] = 1;
								}
							}
						}

						//Kiểm tra lấp được hàng
						for (int j = 0; j < 4; j++)
						{
							if (nCurrentY + j < nBoardHeight - 1)
							{
								bool bLine = 1;
								for (int i = 1; i < nBoardWidth - 1; i++)
								{
									if (pMatrix[(nCurrentY + j) * nBoardWidth + i] == 0)
									{
										bLine = 0;
										break;
									}
								}

								if (bLine == 1)
								{
									nLine++;

									for (int i = 1; i < nBoardWidth - 1; i++)
										pMatrix[(nCurrentY + j) * nBoardWidth + i] = 3;

									vLines.push_back(nCurrentY + j);
								}
							}
						}

						//Tính điểm
						nScore += 25;								//Mỗi lần rơi +25

						if (!vLines.empty())
							nScore += (1 << vLines.size()) * 100;	//Lấy đầy +100/hàng

						//Thiết lập khối mới
						nCurrentX = nBoardWidth / 2 - 4;
						nCurrentY = -4;
						nCurrentRotation = 0;
						nCurrentPiece = nNextPiece;
						nNextPiece = random(0, 6);
					}
			}

			// DISPLAY
					//Tạo hiển thị bảng chơi
			for (int i = 0; i < nBoardWidth; i++)
				for (int j = 0; j < nBoardHeight; j++)
					pBuffer[j * nScreenWidth + i] = detail[pMatrix[j * nBoardWidth + i]];

			//Tạo hiển thị các quân tetromino
			for (int i = 0; i < 8; i++)
			{
				for (int j = 0; j < 4; j++)
				{
					if (tetromino.at(nCurrentPiece).at(nCurrentRotation).at(j * 8 + i) != L'.' && nCurrentY + j >= 0)
					{
						if ((nCurrentY + j) % 2 == 1)
							if ((nCurrentX + i) % 4 == 1 || (nCurrentX + i) % 4 == 2)
								pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 8 * 16 + nCurrentPiece;
							else
								pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 7 * 16 + nCurrentPiece;
						else
							if ((nCurrentX + i) % 4 == 1 || (nCurrentX + i) % 4 == 2)
								pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 7 * 16 + nCurrentPiece;
							else
								pColor[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = 8 * 16 + nCurrentPiece;

						pBuffer[(nCurrentY + j) * nScreenWidth + (nCurrentX + i)] = L'▓';
					}
				}
			}

			//Tạo hiển thị khối tiếp theo
			Block(pBuffer, pColor, nNextPiece, 26, 8);

			//Tạo hiển thi điểm
				//khi thêm chữ số thì dời vị trí in
			if (nScore >= nScoreComp)
			{
				nScorePosX--;
				nScoreComp *= 10;
			}
			Text(pBuffer, pColor, std::to_wstring(nScore), 8 * 16 + 9, nScorePosX, 2);

			//Tạo hiển thị hàng đã lấp
				//khi thêm chữ số thì dời vị trí in
			if (nLine >= nLineComp)
			{
				nLinePosX--;
				nLineComp *= 10;
			}
			Text(pBuffer, pColor, std::to_wstring(nLine), 8 * 16 + 9, nLinePosX, 5);

			//Tạo hiệu ứng xóa hàng được lấp
			if (!vLines.empty())
			{
				WriteConsoleOutputCharacter(hConsole, pBuffer, nScreenWidth * nScreenHeight, { 0,0 }, &dwBytesWritten);
				Sleep(400);

				for (int l = 0; l < vLines.size(); l++)
				{
					for (int i = 1; i < nBoardWidth - 1; i++)
					{
						for (int j = vLines.at(l); j > 0; j--)
						{
							if (j % 2 == 0)
								if (i % 4 == 1 || i % 4 == 2)
									pColor[j * nScreenWidth + i] = pColor[(j - 1) * nScreenWidth + i] - 16;
								else
									pColor[j * nScreenWidth + i] = pColor[(j - 1) * nScreenWidth + i] + 16;
							else
								if (i % 4 == 1 || i % 4 == 2)
									pColor[j * nScreenWidth + i] = pColor[(j - 1) * nScreenWidth + i] + 16;
								else
									pColor[j * nScreenWidth + i] = pColor[(j - 1) * nScreenWidth + i] - 16;

							pMatrix[j * nBoardWidth + i] = pMatrix[(j - 1) * nBoardWidth + i];
						}
						pMatrix[i] = 0;
					}
				}
				vLines.clear();
			}

			//Hiển thị
			Display(hConsole, pBuffer, pColor, dwBytesWritten);
		}

		//GAME OVER
		ClearScreen(pBuffer, pColor, 10, 11);

		//Biến lựa chọn Play Again - Quit
		int nSelect = 0;

		while (1)
		{
			// Đưa text art vào buffer
			for (int i = 0; i < wsGameOver.size(); i++)
				Text(pBuffer, pColor, wsGameOver.at(i), 10 * 16 + 1, 10, 3 + i);

			//	Đưa điểm vào buffer
			Text(pBuffer, pColor, L"════ SCORE ════", 10 * 16 + 3, 12, 11);
			Text(pBuffer, pColor, L"═══════════════", 10 * 16 + 3, 12, 13);

			int nScorePosX = 19;
			int nScoreComp = 100;
			while (nScore >= nScoreComp)
			{
				nScorePosX--;
				nScoreComp *= 100;
			}
			Text(pBuffer, pColor, std::to_wstring(nScore), 10 * 16 + 3, nScorePosX, 12);

			// Tạo nút lệnh và lựa chọn
			if (nSelect == 0)
			{
				Text(pBuffer, pColor, L">> Play Again <<", 10 * 16 + 4, 11, 17);
				Text(pBuffer, pColor, L"      Quit      ", 10 * 16 + 11, 11, 18);

				if (GetKeyState('S') & 0x8000)
					nSelect++;
				if (GetKeyState(13) & 0x8000)
					break;
			}
			else
			{
				Text(pBuffer, pColor, L"   Play Again   ", 10 * 16 + 11, 11, 17);
				Text(pBuffer, pColor, L">>    Quit    <<", 10 * 16 + 6, 11, 18);

				if (GetKeyState('W') & 0x8000)
					nSelect--;
				if (GetKeyState(13) & 0x8000)
					return 0;
			}

			// Hiển thị
			for (int j = 0; j < nScreenHeight; j++)
			{
				for (int i = 0; i < nScreenWidth; i++)
				{
					COORD cPos;
					cPos.X = i;
					cPos.Y = j;
					WriteConsoleOutputAttribute(hConsole, &pColor[j * nScreenWidth + i], 1, cPos, &dwBytesWritten);
				}
			}
			WriteConsoleOutputCharacter(hConsole, pBuffer, nScreenWidth * nScreenHeight, { 0,0 }, &dwBytesWritten);
		}
		delete[] pMatrix;
	}
	
	return 0;
}