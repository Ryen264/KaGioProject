﻿#include "View.h"
#include "Global.h"
#include <Windows.h>
#include <iostream>


void Configure()					//hàm cấu hình, thiết lập kích thước console và thay đổi bảng màu
{
	system("MODE 39, 22");									//thiết lập kích thước console
	system("color 89");

	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);

	//Thay đổi bảng màu
	CONSOLE_SCREEN_BUFFER_INFOEX csbiex;
	csbiex.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);

	GetConsoleScreenBufferInfoEx(hConsoleOutput, &csbiex);

	csbiex.ColorTable[0]  = RGB(0,		188,	212);
	csbiex.ColorTable[1]  = RGB(63,		81,		181);
	csbiex.ColorTable[2]  = RGB(255,	87,		34);
	csbiex.ColorTable[3]  = RGB(255,	235,	59);
	csbiex.ColorTable[4]  = RGB(76,		175,	80);
	csbiex.ColorTable[5]  = RGB(156,	39,		176);
	csbiex.ColorTable[6]  = RGB(237,	28,		36);
	csbiex.ColorTable[7]  = RGB(242,	242,	242);
	csbiex.ColorTable[8]  = RGB(248,	248,	248);
	csbiex.ColorTable[9]  = RGB(20,		20,		20);
	csbiex.ColorTable[10] = RGB(50,		44,		46);
	csbiex.ColorTable[11] = RGB(225,	225,	225);

	SetConsoleScreenBufferInfoEx(hConsoleOutput, &csbiex);

	//Thay đổi kích thước font
	CONSOLE_FONT_INFOEX cfiex;
	cfiex.cbSize = sizeof(CONSOLE_FONT_INFOEX);

	GetCurrentConsoleFontEx(hConsoleOutput, 0, &cfiex);
	cfiex.dwFontSize.Y = 36;

	SetCurrentConsoleFontEx(hConsoleOutput, 0, &cfiex);
}

void ClearScreen(wchar_t* pBuffer, WORD* pColor, int background, int text)
{
	for (int i = 0; i < nScreenWidth; i++)
	{
		for (int j = 0; j < nScreenHeight; j++)
		{
			pBuffer[j * nScreenWidth + i] = L' ';
			pColor[j * nScreenWidth + i] = background * 16 + text;
		}
	}
}

void Background(wchar_t* pBuffer, WORD* pColor)
{
	for (int i = 0; i < nScreenWidth; i++)			//i chạy theo cột
	{
		for (int j = 0; j < nScreenHeight; j++)		//j chạy theo hàng
		{
			pBuffer[j * nScreenWidth + i] = L' ';

			//<cấu trúc màu>		background_color * 16 + text_color
			if (i == 0 || i >= nBoardWidth - 1 || j == nBoardHeight - 1)	//điều kiện ở viền khung
				pColor[j * nScreenWidth + i] = 8 * 16 + 9;					//nền đen, viền khung
			else
				//nếu ở trong bảng chơi
				if (j % 2 == 1)
					//nếu hàng lẻ, cột mod4 = 1, 2 thì nền đen, viền khung; mod4 = 0, 3 thì nền trắng, viền khung
					if (i % 4 == 1 || i % 4 == 2)
						pColor[j * nScreenWidth + i] = 8 * 16 + 9;
					else
						pColor[j * nScreenWidth + i] = 7 * 16 + 9;
				else
					//nếu cột chẵn, thì ngược lại (màu như bàn cờ caro trắng-đen)
					if (i % 4 == 3 || i % 4 == 0)
						pColor[j * nScreenWidth + i] = 8 * 16 + 9;
					else
						pColor[j * nScreenWidth + i] = 7 * 16 + 9;
		}
	}
}

//Hàm vẽ các ô Score, Line, Next
void Frame(wchar_t* wcBuffer, std::wstring wsCaption, int nWidth, int nHeight, int nPosX, int nPosY)
{
	for (int i = nPosX; i < nWidth + nPosX; i++)
	{
		for (int j = nPosY; j < nHeight + nPosY; j++)
		{
			if (i == nPosX)
			{
				if (j == nPosY)
				{
					wcBuffer[j * nScreenWidth + i] = L'╔';
				}
				else if (j == nHeight + nPosY - 1)
				{
					wcBuffer[j * nScreenWidth + i] = L'╚';
				}
				else
				{
					wcBuffer[j * nScreenWidth + i] = L'║';
				}
			}
			else if (i == nWidth + nPosX - 1)
			{
				if (j == nPosY)
				{
					wcBuffer[j * nScreenWidth + i] = L'╗';
				}
				else if (j == nHeight + nPosY - 1)
				{
					wcBuffer[j * nScreenWidth + i] = L'╝';
				}
				else
				{
					wcBuffer[j * nScreenWidth + i] = L'║';
				}
			}
			else
			{
				if (j == nPosY || j == nHeight + nPosY - 1)
				{
					wcBuffer[j * nScreenWidth + i] = L'═';
				}
				else
				{
					wcBuffer[j * nScreenWidth + i] = L' ';
				}

			}
		}
	}

	int CapIndex = nPosY * nScreenWidth + (nPosX + 1);
	for (int i = 0; i < wsCaption.length(); i++, CapIndex++)
	{
		wcBuffer[CapIndex] = wsCaption.at(i);
	}
}

void Barrier(int* pMatrix, wchar_t* pBuffer)
{
	for (int i = 0; i < nBoardWidth; i++)
	{
		for (int j = 0; j < nBoardHeight; j++)
		{
			if (j == nBoardHeight - 1)
				//nếu ở hàng biên dưới bảng
				if (i == 0)
					pMatrix[j * nBoardWidth + i] = 4;		//góc |_
				else if (i == nBoardWidth - 1)
					pMatrix[j * nBoardWidth + i] = 5;		//góc _|
				else
					pMatrix[j * nBoardWidth + i] = 7;		//còn lại
			//nếu ở hàng trong bảng
			else if (i == 0 || i == nBoardWidth - 1)
				pMatrix[j * nBoardWidth + i] = 6;			//2 cột biên trái-phải
			else
				pMatrix[j * nBoardWidth + i] = 0;			//còn lại
		}
	}
}

//Hiển thị text
void Text(wchar_t* pBuffer, WORD* pColor, std::wstring wsContent, WORD wColor, int nPosX, int nPosY)
{
	for (int i = 0; i < wsContent.length(); i++, nPosX++)
	{
		pBuffer[nPosY * nScreenWidth + nPosX] = wsContent.at(i);
		pColor[nPosY * nScreenWidth + nPosX] = wColor;
	}
}

//Hiển thị block
void Block(wchar_t* pBuffer, WORD* pColor, int nTetromino, int nPosX, int nPosY)
{
	for (int j = 0; j < 4; j++)
	{
		for (int i = 0; i < 8; i++)
		{
			if (tetromino.at(nTetromino).at(0).at(j * 8 + i) != L'.')
				pBuffer[(nPosY + j) * nScreenWidth + (nPosX + i)] = tetromino.at(nTetromino).at(0).at(j * 8 + i);
			else
				pBuffer[(nPosY + j) * nScreenWidth + (nPosX + i)] = L' ';
			pColor[(nPosY + j) * nScreenWidth + (nPosX + i)] = 8 * 16 + nTetromino;
		}
	}
}

void Display(HANDLE hConsole, wchar_t* pBuffer, WORD* pColor, DWORD dwBytesWritten)
{
	// Hiển thị
	for (int j = 0; j < nScreenHeight; j++)
	{
		for (int i = 0; i < nScreenWidth; i++)
		{
			COORD cPos;
			cPos.X = i;
			cPos.Y = j;
			WriteConsoleOutputAttribute(hConsole, &pColor[j * nScreenWidth + i], 1, cPos, &dwBytesWritten);
		}
	}
	WriteConsoleOutputCharacter(hConsole, pBuffer, nScreenWidth * nScreenHeight, { 0,0 }, &dwBytesWritten);
}