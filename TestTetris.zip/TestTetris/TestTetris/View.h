#pragma once
#include <iostream>
#include <Windows.h>

void Configure();
void ClearScreen(wchar_t* pBuffer, WORD* pColor, int background, int text);
void Frame(wchar_t* wcBuffer, std::wstring wsCaption, int nWidth, int nHeight, int nPosX, int nPosY);
void Background(wchar_t* pBuffer, WORD* pColor);
void Barrier(int* pMatrix, wchar_t* pBuffer);
void Text(wchar_t* pBuffer, WORD* pColor, std::wstring wsContent, WORD wColor, int nPosX, int nPosY);
void Block(wchar_t* pBuffer, WORD* pColor, int nTetromino, int nPosX, int nPosY);
void Display(HANDLE hConsole, wchar_t* pBuffer, WORD* pColor, DWORD dwBytesWritten);