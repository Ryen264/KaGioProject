#pragma once

bool CheckPiece(int* pMatrix, int nTetromino, int nRotation, int nPosX, int nPosY);
int random(int nMin, int nMax);