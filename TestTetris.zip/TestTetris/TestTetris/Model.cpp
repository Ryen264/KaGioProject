﻿#include "Model.h"
#include "Global.h"
#include <random>

//check quân hợp lệ
bool CheckPiece(int* pMatrix, int nTetromino, int nRotation, int nPosX, int nPosY)
{
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (nPosX + i >= 0 && nPosX + i < nBoardWidth
			 && nPosY + j >= 0 && nPosY + j < nBoardHeight
			 && tetromino.at(nTetromino).at(nRotation).at(j * 8 + i) != L'.'
			 && pMatrix[(nPosY + j) * nBoardWidth + (nPosX + i)] != 0)
				return 0;
		}
	}
	return 1;
}

//random quân tiếp theo
int random(int nMin, int nMax)
{
	std::random_device rd;
	std::mt19937 rng(rd());
	std::uniform_int_distribution<int> uni(nMin, nMax);

	auto num = uni(rng);
	return num;
}