﻿#pragma once
#include <iostream>
#include <vector>

//Hằng số kích thước
const int nScreenWidth = 39;		//chdài của toàn màn hình
const int nScreenHeight = 21;		//chrộng của toàn màn hình

const int nBoardWidth = 22;			//chdài bảng chơi
const int nBoardHeight = 21;		//chrộng bảng chơi

//Hằng số kí tự
const std::wstring detail = L" █▓░╚╝║═";	//các kí tự bằng chỉ số

//Các phím di chuyển
const std::vector<char> key = { 'W', 'A', 'S', 'D', 27 };	//Esc = 27

//Các quân tetromino
const std::vector<std::vector<std::wstring>> tetromino =
{
	// I
	{
		L"....XX.."
		L"....XX.."
		L"....XX.."
		L"....XX..", //xoay 0 deg
		L"........"
		L"........"
		L"XXXXXXXX"
		L"........", //xoay 90 deg
		L"..XX...."
		L"..XX...."
		L"..XX...."
		L"..XX....", //xoay 180 deg
		L"........"
		L"XXXXXXXX"
		L"........"
		L"........"  //xoay 270 deg
	},

	// J
	{
		L"....XX.."
		L"....XX.."
		L"..XXXX.."
		L"........",
		L"........"
		L"..XX...."
		L"..XXXXXX"
		L"........",
		L"........"
		L"..XXXX.."
		L"..XX...."
		L"..XX....",
		L"........"
		L"XXXXXX.."
		L"....XX.."
		L"........"
	},

	// L
	{
		L"..XX...."
		L"..XX...."
		L"..XXXX.."
		L"........",
		L"........"
		L"..XXXXXX"
		L"..XX...."
		L"........",
		L"........"
		L"..XXXX.."
		L"....XX.."
		L"....XX..",
		L"........"
		L"....XX.."
		L"XXXXXX.."
		L"........"
	},

	// O
	{
		L"........"
		L"..XXXX.."
		L"..XXXX.."
		L"........",
		L"........"
		L"..XXXX.."
		L"..XXXX.."
		L"........",
		L"........"
		L"..XXXX.."
		L"..XXXX.."
		L"........",
		L"........"
		L"..XXXX.."
		L"..XXXX.."
		L"........"
	},

	// S
	{
		L"..XX...."
		L"..XXXX.."
		L"....XX.."
		L"........",
		L"........"
		L"....XXXX"
		L"..XXXX.."
		L"........",
		L"........"
		L"..XX...."
		L"..XXXX.."
		L"....XX..",
		L"........"
		L"..XXXX.."
		L"XXXX...."
		L"........"
	},

	// T
	{
		L"..XX...."
		L"..XXXX.."
		L"..XX...."
		L"........",
		L"........"
		L"..XXXXXX"
		L"....XX.."
		L"........",
		L"........"
		L"....XX.."
		L"..XXXX.."
		L"....XX..",
		L"........"
		L"..XX...."
		L"XXXXXX.."
		L"........"
	},

	// Z
	{
		L"....XX.."
		L"..XXXX.."
		L"..XX...."
		L"........",
		L"........"
		L"..XXXX.."
		L"....XXXX"
		L"........",
		L"........"
		L"....XX.."
		L"..XXXX.."
		L"..XX....",
		L"........"
		L"XXXX...."
		L"..XXXX.."
		L"........"
	}
};

//Các kí tự count down và Get Ready
const std::vector<std::wstring> wsThree =
{
		L"──▄",
		L" ─█",
		L"──▀"
};

const std::vector<std::wstring> wsTwo =
{
		L"──▄",
		L"▄─▀",
		L"▀──"
};

const std::vector<std::wstring> wsOne =
{
		L"─▄ ",
		L" █ ",
		L" ▀ "
};

const std::vector<std::wstring> wsReady =
{
		L"▄──┐ ▄── ┌──▄ ▄──┐ ▄ ┬",
		L"█─┬┘ █─  ├──█ █ ┌┘ ▀▄┘",
		L"▀ └─ ▀── ┴  ▀ ▀─┘   ▀ "
};

const std::vector<std::vector<std::wstring>> wsCountDown = { wsThree, wsTwo, wsOne, wsReady };

//Kí tự Game Over
const std::vector<std::wstring> wsGameOver =
{
	L"▄──┐┌──▄ ┌─▄─▄ ▄──",
	L"█ ─┐├──█ │ ▀ █ █─ ",
	L"▀──┘┴  ▀ ┴   ▀ ▀──",
	L"▄──┐ ▄  ┬ ▄── ▄──┐",
	L"█  │ █ ┌┘ █─  █─┬┘",
	L"▀──┘ ▀─┘  ▀── ▀ └─"
};